extends SceneTree
const EngineAdapter=preload("res://infrastructure/engine/adapter.gd")
const COM=preload("res://mission/combat/ports/field_combat.gd")
const scene={"id":"field:scene/river_plain","simulation_scene":"res://content/base/field/river_plain.tscn"}
var checks:=0
var failures:=0
func check(value:bool,label:String)->void:
	checks+=1
	if not value:
		printerr("FAIL ",label)
		failures+=1
func _initialize()->void: trial.call_deferred()
func trial()->void:
	var engine:=EngineAdapter.new(root)
	for flip in [false,true]:
		var scope:="probe-"+str(flip)
		var lease:Dictionary=engine.open_scope(scope)
		check(lease.ok and engine.load_scene(scene,lease.value).ok,"scene")
		await physics_frame
		await physics_frame
		var com:=COM.new(scope)
		var poses:={}
		var rows:=[]
		var handles:=[]
		for team:int in [0,1]:
			var h:={"index":7 if team==0 else 48,"generation":1}
			var x:=1.6*(1 if team==1 else -1)*(-1 if flip else 1)
			var dir:=Vector3.RIGHT*(-signf(x))
			handles.append(h)
			rows.append({"handle":h,"team_key":team,"position":Vector3(x,0,2),"facing":dir})
			poses[h.index]={"position_mm":[roundi(1000*x),1000,2000],"facing_ppm":[roundi(1000000*dir.x),0,0]}
			check(com.enlist(h,{"role":"archer","team":team,"ammo":2}).ok,"enlist")
		check(engine.field_stage_bodies(scope,rows).ok,"stage")
		var hits:=[]
		for tick in range(1,10):
			var intents:=[]
			if tick in [1,4]:
				for h in handles:intents.append({"actor_handle":h,"input_phase":"start" if tick==1 else "release","direction":"up","weapon_slot":1,"target_hint":null})
			var r:=com.step_field(tick,intents,poses,func(q,t):return engine.field_sweep(scope,q,t))
			check(r.ok and r.value.receipts.all(func(v):return v.ok),"tick")
			if r.ok:hits.append_array(r.value.hits)
		check(com.view(handles[0]).value.hp==84 and com.view(handles[1]).value.hp==84,"each hit")
		print("ARCH_DUAL ",JSON.stringify({"mirrored":flip,"hits":hits,"west_hp":com.view(handles[0]).value.hp,"east_hp":com.view(handles[1]).value.hp}))
		engine.release_scope(scope)
	print("ARCH_END checks=",checks," failures=",failures)
	quit(int(failures>0))
