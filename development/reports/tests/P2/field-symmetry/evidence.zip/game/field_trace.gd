extends SceneTree
const Config=preload("res://bootstrap/boot_config.gd")
const App=preload("res://bootstrap/composition_root.gd")
const WAYPOINTS := {"infantry":[46000,0,-4000],"archer":[31000,0,4000],
	"cavalry":[52000,0,-14000],"mounted_archer":[37000,0,12000]}
var app:RefCounted
var scope:=""
var sequence:=0
var tick:=0
var trace:="flanks"
var engaged_order:=false
var troop_by_handle:={}
func _fail(message:String) -> void:
	printerr("FAIL ",message)
	quit(1)
func _ok(r: Dictionary, where: String) -> bool:
	if not r.ok: _fail(where+" "+str(r.error))
	return r.ok

func _send_order(groups: Array, kind: String, at: Variant) -> bool:
	var ids := []
	var revisions := {}
	for group in groups:
		ids.append(group.id)
		revisions[str(group.id)]=group.control_revision
	sequence+=1
	var id := "benchmark-order-%d"%sequence
	var order := {"mission_id":scope,"order_id":id,"issuer_id":"player","formation_ids":ids,
		"order_type":kind,"target_position":at,"target_formation_id":null,
		"parameters":{},"issued_tick":tick+1,"client_sequence":sequence}
	return _ok(app.field_command("field.order",{"order":order,"revisions":revisions},tick,id),"player "+kind)

func _advance() -> bool:
	var hud: Dictionary = app.field_view("hud")
	if not _ok(hud,"command view"): return false
	var groups: Array=hud.value.formations.filter(func(g):return g.controllable and not g.members.is_empty())
	if trace=="together":return _send_order(groups,"move",[52000,0,0])
	for group in groups:
		var role: String = troop_by_handle.get(group.members[0].index,"")
		if not WAYPOINTS.has(role): _fail("formation without a field troop"); return false
		if not _send_order([group],"move",WAYPOINTS[role]): return false
	return true

func _engage_visible() -> bool:
	var hud: Dictionary = app.field_view("hud")
	if not _ok(hud,"contact view"): return false
	if hud.value.targets.is_empty() and tick<900: return true
	var groups: Array=hud.value.formations.filter(func(g):return g.controllable and not g.members.is_empty())
	engaged_order = _send_order(groups,"free_attack",null)
	if engaged_order: print("BENCHMARK free attack at ",tick," known enemy formations ",hud.value.targets.size())
	return engaged_order

func _initialize() -> void: run.call_deferred()
func run()->void:
	var config: Dictionary=Config.resolve([],DisplayServer.get_name(),{}).value
	app=App.new(root)
	assert(app.boot(config).ok)
	var n:=OS.get_cmdline_user_args()[0].to_int()
	var started:Dictionary=app.start_field(n,n*2,241124)
	assert(started.ok)
	scope=started.value
	var max_tick:=2100
	# Jolt updates between Godot fixed frames; simulate every numbered Mission step.
	var stats:={}
	var accepted:=0
	for i in max_tick+15:
		await physics_frame
		var reply:Dictionary=app.field_step()
		if not reply.ok:
			if tick==0 and reply.error.code in ["Unavailable","StaleVersion"]:continue
			print("EARLY ",reply.error)
			break
		tick+=1
		if tick==1:
			for row in reply.value.entities:
				if row.source_slot!=null:troop_by_handle[row.handle.index]=row.components.troop_def_id.get_file()
			if not _advance():return
		if not engaged_order and tick%30==0:
			if not _engage_visible():return
		for report in reply.value.system_reports:
			if report.id!="field.combat":continue
			for hit in report.value.hits:
				print("ARCH_DAMAGE ",JSON.stringify(hit))
				if hit.damage>0:accepted+=1
		if tick>=max_tick:break
	app.shutdown()
	print("ARCH_FIELD steps=",tick," effective=",accepted)
	quit(int(tick<1200))
