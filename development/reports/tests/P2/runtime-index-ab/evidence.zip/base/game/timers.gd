extends RefCounted
static var index_usec:=0
static var think_usec:=0
static var fast:=false
