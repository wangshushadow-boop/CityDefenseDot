# 001 自定义近距千槽实战独立审查

**PASS，已合入。** 原版提交为 `a5c6e9b`，脚本 SHA-256 为 `3de46f9b957bb17b01c01db4ee78d68b3c6afe756e7aa0ecf9d40c0dca81a02e`。两次独立冷包运行验收的是加强版提交 `7d360c2`，脚本 SHA-256 为 `52f2a9e02a1a6de507edb15a2d462f4fe0ea662211ab987a3c40128822044371`。合入提交 `3e99f22` 的脚本逐字节相同；`git diff --exit-code 7d360c2 3e99f22 -- game/tests/p2/field` 无差异。原始河原测试基类来自 `85cd9db`，SHA-256 为 `4b5db2e7621227e5b6af3437e3e31f8a77b0e80695c49560e86f1251dbd34a89`。

加强后的入口强制要求首次补员发生于起步与撤退之间、500 < 实际入场 < 1000、未入场数等于 1000 减已入场数、确有人员撤退，且有可从伤员中归给唯一胜方的俘虏。程序逐槽对照 COM 和规则层提交的伤情与退出事实，校验常规战场结果和专服回执。初版 `3de46f9b` 因欠缺未入场与实际撤退的显式断言已由此版替换。

## 真实成品与复跑

两次均使用 `out/p2-field-final/31eca5d8dfdf-40b6dfa0026a/server.pck`，SHA-256 为 `e23e7b8a6143af5c570e73a9f7c309598cbcd0d496e4ca3180f8bb6ef8c4274e`，运行前后和构建清单一致。各进程的 cwd 为空，用户目录互相隔离。启动器先确认交付包本身无测试目录，然后通过 Godot 的 PCKPacker 和 ProjectSettings.load_resource_pack 挂载外部冻结的 QA 脚本。成品内的正式脚本、模型和场景提供业务资源。额外的只读审计脚本用于第二次运行时记录击倒当步的攻击者。所有临时测试包均写入独立用户目录。

从仓库根目录执行以下 PowerShell 命令。RunDirectory 应为新的证据目录。审计模式将 Mode 设为 audit。

```powershell
& ./out/p2-qa/final-review-five/close-mixed/replay.ps1 -Package out/p2-field-final/31eca5d8dfdf-40b6dfa0026a/server.pck -Engine 'D:/Program/Godot/Standard/Godot_v4.7.2-stable_win64_console.exe' -Mode run -RunDirectory out/p2-qa/final-review-five/close-mixed/another-run
```

## 成果及证据

两次运行均为 7112 项、0 失败、退出 0。500 个开场来源为 250 步、150 弓、50 骑、50 骑射，另有 100 匹马与 500 个预留来源。正式第 1948 步，槽 645 的手柄 291/1 对槽 73 的手柄 146/1 造成唯一的当步有效伤害 24 点并将其击倒。第 2040 步有真实增援；第 2041 步本方撤退，胜方 1 对槽 73 获得俘虏候选。最终 501 入场、499 未入场、250 撤退、250 存活、1 伤。第 1986 步另一个无来源槽的实体倒地，没有多算人头。见 `final-run/console.log` 与 `final-audit/console.log`。

两次分别比对自定义地图的 5 个标记和 16 个定义。实质变化只有西、东出生点 x 坐标从 −52、+52 m 改到 +3.25、−3.25 m，出生列数从 24 增至 80。中线和出口不变，其余内容、规则、伤害与结果由成品运行。见 `fixture-delta.json`、`audit-fixture-delta.json`。

本结果证明自定义混战可同时产生千槽来源守恒、未入场兵员、补员、真实撤退及正俘获。默认河原严格冲锋仍是另一条已记录失败的测试；图形性能、人工验收及战役资产持久转移由各自独立门禁记录。
