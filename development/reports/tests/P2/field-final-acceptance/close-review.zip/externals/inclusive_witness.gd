extends "res://tests/p2/field/close_mixed.gd"

func observe(snapshot: Dictionary) -> void:
	super.observe(snapshot)
	for report in snapshot.system_reports:
		if report.id!="field.combat":continue
		for event in report.value.events:
			if event.type!="downed":continue
			var sources:=[]
			for hit in report.value.hits:
				if hit.target!=event.actor_handle or hit.damage<=0 or hit.blocked:continue
				sources.append({"slot":known_handles.get(key(hit.attacker),-1),"handle":hit.attacker,"damage":hit.damage})
			print("REVIEW_MIXED_KNOCKDOWN ",JSON.stringify({"tick":snapshot.tick,"target":event.actor_handle,
				"victim_slot":known_handles.get(key(event.actor_handle),-1),"sources":sources}))
