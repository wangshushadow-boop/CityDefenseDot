extends SceneTree

func _initialize() -> void:
	var args := OS.get_cmdline_user_args()
	if args.size()!=4 or DirAccess.dir_exists_absolute("res://tests"):
		printerr("FAIL initial package is missing arguments or contains tests")
		quit(1)
		return
	var stamp: Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://build_info.json"))
	if stamp.target!="server" or stamp.git_commit!=args[3]:
		quit(1)
		return
	var output := ProjectSettings.globalize_path("user://external-qa-harness.pck")
	var pack := PCKPacker.new()
	if pack.pck_start(output)!=OK or pack.add_file("res://tests/p2/field/run.gd",args[0])!=OK or pack.add_file("res://tests/p2/field/close_mixed.gd",args[1])!=OK:
		printerr("FAIL create QA-only pack")
		quit(1)
		return
	if args[2]=="audit" and pack.add_file("res://tests/p2/field/witness.gd",args[0].get_base_dir().path_join("inclusive_witness.gd"))!=OK:
		quit(1)
		return
	if pack.flush()!=OK or not ProjectSettings.load_resource_pack(output,false):
		quit(1)
		return
	var script:Script=load("res://tests/p2/field/close_mixed.gd")
	if script==null or not script.can_instantiate():
		printerr("FAIL exact fixture parse")
		quit(1)
		return
	print("REVIEW_COLD server=",stamp.git_commit," original_tests=absent fixture=",FileAccess.get_sha256(script.resource_path))
	if args[2]=="parse":
		quit(0)
		return
	if args[2]=="audit":
		script=load("res://tests/p2/field/witness.gd")
	set_script(script)
	call_deferred("_initialize")
