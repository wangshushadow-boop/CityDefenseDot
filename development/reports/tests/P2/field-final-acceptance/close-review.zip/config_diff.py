from pathlib import Path
import hashlib, json, sys
working=Path(__file__).resolve().parent
original=working.parent/'route-retention/game/content/base/field'
user=working/sys.argv[1]
packed=next(user.rglob('field-accept-*-markers.json'))
definitions=packed.with_name(packed.name.replace('-markers','-definitions'))
base_marker=json.loads((original/'river_plain.scene.json').read_text('utf-8'))
changed_marker=json.loads(packed.read_text('utf-8'))
base_def=json.loads((original/'field.json').read_text('utf-8'))
changed_def=json.loads(definitions.read_text('utf-8'))
deltas={}
for marker in base_marker['markers']:
    name=marker['id']
    if name in ['east','west']:
        old=marker['position_mm'].copy()
        marker['position_mm']=[3250 if name=='west' else -3250,0,0]
        deltas[name]={'original':old,'fixture':marker['position_mm']}
for item in base_def:
    if item['id']=='field:scene/river_plain':
        old=item['metadata']['spawn_columns']
        item['metadata']['spawn_columns']=80
        deltas['spawn_columns']={'original':old,'fixture':80}
assert changed_marker==base_marker and changed_def==base_def
assert deltas['spawn_columns']['original']==24
assert {k for k in deltas}=={'west','east','spawn_columns'}
print(json.dumps({'equal_except':deltas,'markers':len(base_marker['markers']),'definitions':len(base_def)},indent=2))
