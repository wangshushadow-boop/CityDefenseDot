param(
    [Parameter(Mandatory)][string]$Package,
    [Parameter(Mandatory)][string]$Engine,
    [ValidateSet('run','audit','parse')][string]$Mode='run',
    [Parameter(Mandatory)][string]$RunDirectory
)
$ErrorActionPreference='Stop'
$pack=(Resolve-Path -LiteralPath $Package).Path
$godot=(Resolve-Path -LiteralPath $Engine).Path
$entry=Join-Path $PSScriptRoot 'externals'
$manifest=Get-Content -Raw -LiteralPath (Join-Path (Split-Path $pack) 'manifest.json') | ConvertFrom-Json
if ((Get-FileHash -LiteralPath $pack).Hash -ne $manifest.artifacts.'server.pck'.sha256) {throw 'Server package SHA mismatch'}
if (Test-Path -LiteralPath $RunDirectory) {throw 'Choose an unused evidence directory'}
$work=(New-Item -ItemType Directory -Path $RunDirectory).FullName
$cold=(New-Item -ItemType Directory -Path (Join-Path $work 'cold')).FullName
$user=(New-Item -ItemType Directory -Path (Join-Path $work 'user')).FullName
$env:APPDATA=$user
$env:LOCALAPPDATA=$user
Push-Location -LiteralPath $cold
try {
    & $godot --headless --main-pack $pack --script (Join-Path $entry 'cold_loader.gd') --log-file (Join-Path $work 'engine.log') -- (Join-Path $entry 'run.gd') (Join-Path $entry 'close_mixed.gd') $Mode $manifest.git_commit *> (Join-Path $work 'console.log')
    $code=$LASTEXITCODE
} finally { Pop-Location }
Get-Content -LiteralPath (Join-Path $work 'console.log') -Tail 4
if ((Get-FileHash -LiteralPath $pack).Hash -ne $manifest.artifacts.'server.pck'.sha256) {throw 'Server package changed during fixture'}
exit $code
