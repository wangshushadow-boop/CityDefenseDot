extends SceneTree
var rows:Array
var poses:Dictionary
var riders:Dictionary
var expected:Dictionary

func _mm(v: Vector3, scale: int = 1000) -> Array:
	return [roundi(v.x*scale),roundi(v.y*scale),roundi(v.z*scale)]

func current() -> Dictionary:
	var result:={}
	for row in rows:
		var p:Dictionary=poses[row.handle.index]
		var origin:Vector3=p.position+Vector3.UP
		if riders.has(row.handle.index):origin+=Vector3.UP*.8
		result[row.handle.index]={"position_mm":_mm(origin),"facing_ppm":_mm(p.heading,1000000),"speed_mm_tick":roundi(p.velocity.length()*1000.0/60.0)}
	return result

func pack() -> Array:
	var lanes:=PackedVector3Array()
	var flags:=PackedByteArray()
	lanes.resize(rows.size()*3)
	flags.resize(rows.size())
	for i in rows.size():
		var id:int=rows[i].handle.index
		var p:Dictionary=poses[id]
		lanes[i*3]=p.position
		lanes[i*3+1]=p.heading
		lanes[i*3+2]=p.velocity
		flags[i]=int(riders.has(id))
	return [lanes,flags]

func gd_kernel(lanes:PackedVector3Array, flags:PackedByteArray) -> PackedInt32Array:
	var result:=PackedInt32Array()
	result.resize(flags.size()*7)
	for i in flags.size():
		var o:Vector3=lanes[3*i]+Vector3.UP
		if flags[i]:o+=Vector3.UP*.8
		var h:Vector3=lanes[3*i+1]
		var v:Vector3=lanes[3*i+2]
		result[7*i]=roundi(o.x*1000)
		result[7*i+1]=roundi(o.y*1000)
		result[7*i+2]=roundi(o.z*1000)
		result[7*i+3]=roundi(h.x*1000000)
		result[7*i+4]=roundi(h.y*1000000)
		result[7*i+5]=roundi(h.z*1000000)
		result[7*i+6]=roundi(v.length()*1000.0/60.0)
	return result

func native_sample(data:Array) -> PackedInt32Array:
	return ClassDB.class_call_static(&"FieldPoseProbe",&"pack_rows",data[0],data[1])

func unpack(lanes:PackedInt32Array)->Dictionary:
	var result:={}
	for i in rows.size():
		var o:=7*i
		result[rows[i].handle.index]={"position_mm":[lanes[o],lanes[o+1],lanes[o+2]],"facing_ppm":[lanes[o+3],lanes[o+4],lanes[o+5]],"speed_mm_tick":lanes[o+6]}
	return result

func gd_full()->Dictionary:
	var data:=pack()
	return unpack(gd_kernel(data[0],data[1]))

func native_full()->Dictionary:
	return unpack(native_sample(pack()))

func fail(reason:String)->void:
	printerr("ARCH_NATIVE_FAIL ",reason)
	quit(1)

func _initialize() -> void:
	var args:=OS.get_cmdline_user_args()
	var f:=FileAccess.open(args[0],FileAccess.READ)
	var data:Dictionary=f.get_var(false)
	f.close()
	rows=data.rows
	poses=data.poses
	riders=data.riders
	expected=data.expected
	var loaded:=GDExtensionManager.load_extension("res://pose.gdextension")
	if not loaded in [GDExtensionManager.LOAD_STATUS_OK,GDExtensionManager.LOAD_STATUS_ALREADY_LOADED]:
		fail("extension load")
		return
	var packed:=pack()
	var converted:=native_sample(packed)
	var native_map:=unpack(converted)
	if gd_full()!=expected or current()!=expected or native_map!=expected or converted!=gd_kernel(packed[0],packed[1]):
		for id in expected:
			if expected[id]!=native_map.get(id):
				printerr("MISMATCH ",id," ",expected[id]," ",native_map.get(id))
				break
		fail("pose mismatch")
		return
	var edge:=[PackedVector3Array([Vector3(-.0625,.0625,0),Vector3(0,0,-1),Vector3(0,0,0),Vector3(.0625,-.0625,1),Vector3(1,0,0),Vector3(3,0,4)]),PackedByteArray([0,1])]
	if native_sample(edge)!=gd_kernel(edge[0],edge[1]) or not native_sample([PackedVector3Array(),PackedByteArray()]).is_empty() or not native_sample([PackedVector3Array(),PackedByteArray([1])]).is_empty():
		fail("boundary cases")
		return
	var names:=["current","pack","gd_packed","native_packed","unpack","native_full","gd_full","native_empty"]
	var samples:={}
	for label in names:samples[label]=[]
	var empty:=[PackedVector3Array(),PackedByteArray()]
	for repeat in 195:
		for j in names.size():
			var label:String=names[(j+repeat)%names.size()]
			var start:=Time.get_ticks_usec()
			match label:
				"current":current()
				"pack":pack()
				"gd_packed":gd_kernel(packed[0],packed[1])
				"native_packed":native_sample(packed)
				"unpack":unpack(converted)
				"native_full":native_full()
				"gd_full":gd_full()
				"native_empty":
					for i in 100:native_sample(empty)
			var usec:float=Time.get_ticks_usec()-start
			if label=="native_empty":usec/=100.0
			if repeat>=35:samples[label].append(usec)
	var out:=FileAccess.open(args[1],FileAccess.WRITE)
	out.store_string(JSON.stringify({"rows":rows.size(),"ints_compared":converted.size(),"tick":data.tick,"seed":data.seed,"riders":riders.size(),"warm":35,"iterations":160,"samples_us":samples,"digest":converted.to_byte_array().hex_encode().sha256_text()}))
	out.close()
	print("ARCH_NATIVE_PASS ints=",converted.size()," rows=",rows.size()," tick=",data.tick," riders=",riders.size())
	quit()
