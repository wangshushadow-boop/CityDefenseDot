#include "gdextension_interface.h"
#include <cstdint>
#include <cmath>
#include <initializer_list>

// Prototype restricted to the installed float_64 ABI; sizes come from this engine's dump.
struct Name { alignas(8) unsigned char code[8]; };
struct Packed { alignas(8) unsigned char code[16]; };
struct Triple { float x,y,z; };
constexpr auto names=GDEXTENSION_VARIANT_TYPE_STRING_NAME;
constexpr auto vectors=GDEXTENSION_VARIANT_TYPE_PACKED_VECTOR3_ARRAY;
constexpr auto bytes=GDEXTENSION_VARIANT_TYPE_PACKED_BYTE_ARRAY;
constexpr auto integers=GDEXTENSION_VARIANT_TYPE_PACKED_INT32_ARRAY;
static GDExtensionInterfaceGetProcAddress get;
static GDExtensionClassLibraryPtr library;
template<class T> static T api(const char* symbol) {return reinterpret_cast<T>(get(symbol));}
static GDExtensionVariantGetInternalPtrFunc vec_ptr, byte_ptr;
static GDExtensionInterfacePackedVector3ArrayOperatorIndexConst read_vec;
static GDExtensionInterfacePackedByteArrayOperatorIndexConst read_flag;
static GDExtensionInterfacePackedInt32ArrayOperatorIndex write_int;
static GDExtensionPtrBuiltInMethod vec_size, flag_size, out_resize;
static GDExtensionPtrConstructor packed_new;
static GDExtensionPtrDestructor packed_destroy, name_destroy;
static GDExtensionVariantFromTypeConstructorFunc set_result;
static GDExtensionInterfaceVariantDestroy clear_result;
static GDExtensionInterfaceVariantGetType variant_type;
static GDExtensionInterfaceStringNameNewWithLatin1Chars make_name;
static Name type_name;
static void compute(const void* v,const void* flags,void* out) {
    int64_t n=0, lanes=0;
    vec_size(const_cast<void*>(v),nullptr,&lanes,0);
    flag_size(const_cast<void*>(flags),nullptr,&n,0);
    if(n<=0 || n>1000000 || lanes!=n*3) return;
    int64_t length=n*7,err=0;
    const void* args[]={&length};
    out_resize(out,args,&err,1);
    if(err!=0) return;
    const auto* pos=static_cast<const Triple*>(read_vec(v,0));
    const auto* mounted=read_flag(flags,0);
    auto* answer=write_int(out,0);
    for(int64_t i=0;i<n;++i) {
        const auto& p=pos[i*3]; const auto& h=pos[i*3+1]; const auto& velocity=pos[i*3+2];
        const float y=(p.y+1.0f)+(mounted[i]?0.8f:0.0f);
        const float speed=std::sqrt(velocity.x*velocity.x+velocity.y*velocity.y+velocity.z*velocity.z);
        const double vals[]={double(p.x)*1000,double(y)*1000,double(p.z)*1000,
                              double(h.x)*1000000,double(h.y)*1000000,double(h.z)*1000000,
                              double(speed)*1000/60};
        for(int j=0;j<7;++j) answer[i*7+j]=static_cast<int32_t>(std::round(vals[j]));
    }
}
static void var_call(void*,GDExtensionClassInstancePtr,const GDExtensionConstVariantPtr* args,GDExtensionInt count,GDExtensionVariantPtr result,GDExtensionCallError *error) {
    if(count!=2){error->error=count>2?GDEXTENSION_CALL_ERROR_TOO_MANY_ARGUMENTS:GDEXTENSION_CALL_ERROR_TOO_FEW_ARGUMENTS;return;}
    for(int i=0;i<2;i++) {
        const auto type=i==0?vectors:bytes;
        if(variant_type(args[i])!=type){error->error=GDEXTENSION_CALL_ERROR_INVALID_ARGUMENT;error->argument=i;error->expected=type;return;}
    }
    Packed out;
    packed_new(&out,nullptr);
    compute(vec_ptr(const_cast<void*>(args[0])),byte_ptr(const_cast<void*>(args[1])),&out);
    clear_result(result);
    set_result(result,&out);
    packed_destroy(&out);
    error->error=GDEXTENSION_CALL_OK;
}
static void ptr_call(void*,GDExtensionClassInstancePtr,const GDExtensionConstTypePtr* args,GDExtensionTypePtr out) { compute(args[0],args[1],out); }
static void start(void*,GDExtensionInitializationLevel lvl) {
    if(lvl!=GDEXTENSION_INITIALIZATION_SCENE)return;
    make_name=api<GDExtensionInterfaceStringNameNewWithLatin1Chars>("string_name_new_with_latin1_chars");
    auto dtor=api<GDExtensionInterfaceVariantGetPtrDestructor>("variant_get_ptr_destructor");
    name_destroy=dtor(names); packed_destroy=dtor(integers);
    auto builtin=api<GDExtensionInterfaceVariantGetPtrBuiltinMethod>("variant_get_ptr_builtin_method");
    Name size,resize,parent,method,blank,an,bn;
    make_name(&size,"size",0); make_name(&resize,"resize",0); make_name(&parent,"Object",0); make_name(&type_name,"FieldPoseProbe",0);
    make_name(&method,"pack_rows",0);make_name(&blank,"",0);make_name(&an,"vectors",0);make_name(&bn,"mounted",0);
    vec_size=builtin(vectors,&size,3173160232LL);flag_size=builtin(bytes,&size,3173160232LL);
    out_resize=builtin(integers,&resize,848867239LL);
    auto internal=api<GDExtensionInterfaceGetVariantGetInternalPtrFunc>("variant_get_ptr_internal_getter");
    vec_ptr=internal(vectors);byte_ptr=internal(bytes);
    read_vec=api<GDExtensionInterfacePackedVector3ArrayOperatorIndexConst>("packed_vector3_array_operator_index_const");
    read_flag=api<GDExtensionInterfacePackedByteArrayOperatorIndexConst>("packed_byte_array_operator_index_const");
    write_int=api<GDExtensionInterfacePackedInt32ArrayOperatorIndex>("packed_int32_array_operator_index");
    packed_new=api<GDExtensionInterfaceVariantGetPtrConstructor>("variant_get_ptr_constructor")(integers,0);
    set_result=api<GDExtensionInterfaceGetVariantFromTypeConstructor>("get_variant_from_type_constructor")(integers);
    clear_result=api<GDExtensionInterfaceVariantDestroy>("variant_destroy");
    variant_type=api<GDExtensionInterfaceVariantGetType>("variant_get_type");
    GDExtensionClassCreationInfo6 info{};info.is_abstract=true;info.is_exposed=true;
    api<GDExtensionInterfaceClassdbRegisterExtensionClass6>("classdb_register_extension_class6")(library,&type_name,&parent,&info);
    auto str_new=api<GDExtensionInterfaceVariantGetPtrConstructor>("variant_get_ptr_constructor")(GDEXTENSION_VARIANT_TYPE_STRING,0);
    alignas(8) unsigned char empty[8];str_new(empty,nullptr);
    GDExtensionPropertyInfo result_info{integers,&blank,&blank,0,empty,6};
    GDExtensionPropertyInfo ins[2]={{vectors,&an,&blank,0,empty,6},{bytes,&bn,&blank,0,empty,6}};
    GDExtensionClassMethodArgumentMetadata meta[2]{};
    GDExtensionClassMethodInfo method_info{};method_info.name=&method;method_info.call_func=var_call;method_info.ptrcall_func=ptr_call;
    method_info.method_flags=GDEXTENSION_METHOD_FLAG_NORMAL|GDEXTENSION_METHOD_FLAG_STATIC;
    method_info.has_return_value=true;method_info.return_value_info=&result_info;method_info.argument_count=2;
    method_info.arguments_info=ins;method_info.arguments_metadata=meta;
    api<GDExtensionInterfaceClassdbRegisterExtensionClassMethod>("classdb_register_extension_class_method")(library,&type_name,&method_info);
    dtor(GDEXTENSION_VARIANT_TYPE_STRING)(empty);
    for(Name* n: {&size,&resize,&parent,&method,&blank,&an,&bn})name_destroy(n);
}
static void stop(void*,GDExtensionInitializationLevel lvl) {
    if(lvl!=GDEXTENSION_INITIALIZATION_SCENE)return;
    api<GDExtensionInterfaceClassdbUnregisterExtensionClass>("classdb_unregister_extension_class")(library,&type_name);
    name_destroy(&type_name);
}
extern "C" __declspec(dllexport) GDExtensionBool arch_init(GDExtensionInterfaceGetProcAddress resolve,GDExtensionClassLibraryPtr lib,GDExtensionInitialization* init){
    get=resolve;library=lib;init->minimum_initialization_level=GDEXTENSION_INITIALIZATION_SCENE;
    init->initialize=start;init->deinitialize=stop;return true;
}
