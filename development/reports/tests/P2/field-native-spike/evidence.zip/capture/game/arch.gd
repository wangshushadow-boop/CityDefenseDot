extends SceneTree
const Config=preload("res://bootstrap/boot_config.gd")
const App=preload("res://bootstrap/composition_root.gd")
const WAYPOINTS := {"infantry":[46000,0,-4000],"archer":[31000,0,4000],
	"cavalry":[52000,0,-14000],"mounted_archer":[37000,0,12000]}
var app:RefCounted
var scope:=""
var sequence:=0
var tick:=0
var trace:="flanks"
var engaged_order:=false
var troop_by_handle:={}
func _fail(message:String) -> void:
	printerr("FAIL ",message)
	quit(1)
func _ok(r: Dictionary, where: String) -> bool:
	if not r.ok: _fail(where+" "+str(r.error))
	return r.ok

func _send_order(groups: Array, kind: String, at: Variant) -> bool:
	var ids := []
	var revisions := {}
	for group in groups:
		ids.append(group.id)
		revisions[str(group.id)]=group.control_revision
	sequence+=1
	var id := "benchmark-order-%d"%sequence
	var order := {"mission_id":scope,"order_id":id,"issuer_id":"player","formation_ids":ids,
		"order_type":kind,"target_position":at,"target_formation_id":null,
		"parameters":{},"issued_tick":tick+1,"client_sequence":sequence}
	return _ok(app.field_command("field.order",{"order":order,"revisions":revisions},tick,id),"player "+kind)

func _advance() -> bool:
	var hud: Dictionary = app.field_view("hud")
	if not _ok(hud,"command view"): return false
	var groups: Array=hud.value.formations.filter(func(g):return g.controllable and not g.members.is_empty())
	if trace=="together":return _send_order(groups,"move",[52000,0,0])
	for group in groups:
		var role: String = troop_by_handle.get(group.members[0].index,"")
		if not WAYPOINTS.has(role): _fail("formation without a field troop"); return false
		if not _send_order([group],"move",WAYPOINTS[role]): return false
	return true

func _engage_visible() -> bool:
	var hud: Dictionary = app.field_view("hud")
	if not _ok(hud,"contact view"): return false
	if hud.value.targets.is_empty() and tick<900: return true
	var groups: Array=hud.value.formations.filter(func(g):return g.controllable and not g.members.is_empty())
	engaged_order = _send_order(groups,"free_attack",null)
	if engaged_order: print("BENCHMARK free attack at ",tick," known enemy formations ",hud.value.targets.size())
	return engaged_order

func _initialize() -> void: run.call_deferred()
func run() -> void:
	var args:=OS.get_cmdline_user_args()
	var n:=int(args[0])
	app=App.new(root)
	var config: Dictionary=Config.resolve([],DisplayServer.get_name(),{}).value
	assert(app.boot(config).ok)
	var begun:Dictionary=app.start_field(n,n*2,241124)
	assert(begun.ok)
	scope=begun.value
	var output:=FileAccess.open(args[1],FileAccess.WRITE)
	var auth:=[]
	var hud_times:=[]
	var input_times:=[]
	var vis_times:=[]
	var captures:=[]
	var shots:=0
	var hits:=0
	var downs:=0
	var contact:=-1
	var count:=128
	var warm:=120
	for i in 2800:
		await physics_frame
		var before:=Time.get_ticks_usec()
		var reply:Dictionary=app.field_step()
		if not reply.ok:
			if tick==0 and reply.error.code in ["Unavailable","StaleVersion"]: continue
			_fail(str(reply.error))
			return
		var sim:=Time.get_ticks_usec()-before
		tick+=1
		assert(tick==reply.value.tick)
		if tick==1038:
			var events:=0
			for report in reply.value.system_reports:
				if report.id=="field.combat":events=report.value.events.size()
			print("ARCH_CAPTURE tick=",tick," opening=",n," contact=",contact," entities=",reply.value.entities.size()," events=",events)
			output.close()
			app.shutdown()
			quit(int(contact<0))
			return
		if tick==1:
			for row in reply.value.entities:
				if row.source_slot!=null: troop_by_handle[row.handle.index]=row.components.troop_def_id.get_file()
			if not _advance(): return
		if not engaged_order and tick%30==0:
			if not _engage_visible(): return
		var record:=contact>0 and tick>contact+warm
		for report in reply.value.system_reports:
			if report.id=="field.combat":
				if report.value.hits.size()>0 and contact<0: contact=tick
				if record: hits+=report.value.hits.size()
				for ev in report.value.events:
					if ev.type=="projectile_launched":
						if contact<0: contact=tick
						if record: shots+=1
					if record and ev.type=="downed": downs+=1
		if not record: continue
		auth.append(sim)
		before=Time.get_ticks_usec()
		var hud:Dictionary=app.field_view("hud")
		hud_times.append(Time.get_ticks_usec()-before)
		before=Time.get_ticks_usec()
		var inp:Dictionary=app.field_view("input")
		input_times.append(Time.get_ticks_usec()-before)
		before=Time.get_ticks_usec()
		var vis:Dictionary=app.field_view("visual")
		vis_times.append(Time.get_ticks_usec()-before)
		assert(hud.ok and inp.ok and vis.ok)
		if auth.size()%16==0:
			var capture:=JSON.stringify([reply.value.entities,reply.value.system_reports,hud.value,inp.value,vis.value]).replace(scope,"freeze-scope")
			captures.append(capture.sha256_text())
		if auth.size()==count: break
	output.store_string(JSON.stringify({"captures":captures,"auth":auth,"hud":hud_times,"input":input_times,"visual":vis_times,"contact":contact,"shots":shots,"hits":hits,"downed":downs,"last_tick":tick}))
	output.close()
	app.shutdown()
	print("ARCH steps=",auth.size()," captures=",captures.size()," contact=",contact," hits=",hits," shots=",shots)
	quit(int(auth.size()!=count or hits==0 or shots==0))
