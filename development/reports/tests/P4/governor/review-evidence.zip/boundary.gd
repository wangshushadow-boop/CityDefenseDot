extends SceneTree

const Camp = preload("res://campaign/runtime.gd")
const F = preload("res://tests/p1/application/fixture.gd")
const R = preload("res://contracts/result.gd")
const C = preload("res://contracts/canonical.gd")
const E := "encounter/44444444-4444-4444-8444-444444444444"
const PARTY := "party/55555555-5555-4555-8555-555555555555"
var camp := Camp.new()
var counter := 0
var checks := 0
var failed := []

func cmd(op: String, args: Dictionary = {}) -> Dictionary:
	counter += 1
	return camp.character_command(op,args,"review/%d" % counter,func(_v,_r):return R.ok())

func confirm(truth: bool, note: String) -> bool:
	checks += 1
	if not truth:
		failed.append(note)
		printerr("FAIL ",note)
	return truth

func trial() -> void:
	var settings := F.options("review")
	if not confirm(camp.create_world(settings.seed,settings.start_def,F.CONTENT).ok and cmd("create",{"culture":"river"}).ok,"original sand box and kin"): return
	var before := camp.save_snapshot().value as Dictionary
	var model := camp.character_view().value as Dictionary
	var governor: String=model.heirs[0].id
	var founder: String=model.player_id
	var vacancy: Dictionary=model.governance
	var appoint := {"settlement_id":vacancy.settlement_id,"hero_id":governor}
	var frozen := camp.freeze_for_encounter(E)
	if not confirm(frozen.ok,"old encounter holds world"): return
	confirm(not cmd("governor_open").ok and camp.release_freeze(frozen.value).ok,"frozen world rejects a new manor")
	if not confirm(cmd("governor_open").ok and cmd("governor_assign",appoint).ok,"actual management actions"): return
	var forecast: Dictionary=camp.character_view().value.governance.next_report
	var arrested := {"source":"review/hostage","kind":"capture","location":PARTY,"hero_id":founder}
	if not confirm(cmd("outcome",arrested).ok,"family head becomes hostage"): return
	model=camp.character_view().value
	confirm(not model.governance.can_manage and model.governance.governor_id==governor,"incapacitation stops orders but not deputy office")
	confirm(not cmd("governor_dismiss",{"settlement_id":vacancy.settlement_id}).ok,"hostage cannot dismiss their deputy")
	if not confirm(camp.step_until(1440,100).ok,"ordinary calendar during captivity"): return
	confirm(camp.character_view().value.governance.last_report==forecast,"capture of the clan head preserves incumbent contribution")
	var token := camp.prepare_day(2)
	if not confirm(token.ok,"begin ordinary second day"): return
	var late: Dictionary=cmd("outcome",{"source":"review/death","kind":"death","hero_id":governor})
	confirm(not late.ok and camp.commit_day(token.value).ok,"governor cannot change mid-plan")
	var last: Dictionary=camp.character_view().value.governance.last_report
	if not confirm(cmd("outcome",{"source":"review/death","kind":"death","hero_id":governor}).ok,"authoritative death after day commits"): return
	var orphanless: Dictionary=camp.save_snapshot().value
	var cold := Camp.new()
	if not confirm(cold.restore(orphanless).ok,"reload despite last report citing a now deceased incumbent"): return
	var released: Dictionary=cold.character_view().value.governance
	confirm(released.last_report==last and released.governor_id==null and released.next_report.prosperity_bonus==0,"historical service retained in ended term")
	confirm(C.encode(cold.character_view().value).ok,"projection of deceased and captive family is exportable")
	var bad: Dictionary=orphanless.duplicate(true)
	bad.governance.governor_id=governor
	confirm(not cold.restore(bad).ok and cold.save_snapshot().value==orphanless,"orphaned office rejected, previous world stays active")
	confirm(not cmd("governor_assign",appoint).ok,"dead family member cannot return to office")
	if not confirm(cold.step_until(4320,100).ok,"calendar advances on empty office"): return
	var empty: Dictionary=cold.character_view().value.governance
	confirm(empty.last_report.governor_id==null and empty.last_report.loyalty_base==-1 and empty.loyalty==last.loyalty_after-1,"next day has no inherited officer bonus")
	confirm(cold.restore(before).ok and cold.save_snapshot().value==before,"restore older no-estate world fully replaces previous estate")

func _initialize() -> void:
	trial()
	print("P4_REVIEW ",JSON.stringify({"checks":checks,"failures":failed,"case":"world_freeze_and_term_continuity"}))
	quit(int(not failed.is_empty() or checks!=20))
