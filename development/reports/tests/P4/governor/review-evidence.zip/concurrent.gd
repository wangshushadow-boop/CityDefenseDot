extends SceneTree
const Camp=preload("res://campaign/runtime.gd")
const App=preload("res://application/game_session.gd")
const Store=preload("res://infrastructure/persistence/save_service.gd")
const F=preload("res://tests/p1/application/fixture.gd")
const R=preload("res://contracts/result.gd")
var checks:=0
var failures:=[]

class Client:
	var game
	var principal:=RefCounted.new()
	var slot: String
	var scope: String
	var session: String

	func _init(path: String, id: String) -> void:
		slot=id
		game=App.new(Store.new(path),func():return Camp.new(),func(_m):return null,authority)
	func authority(token: Variant,_op: String,body: Dictionary) -> Dictionary:
		return R.ok("player") if is_same(token,principal) and body.get("session_id")==session and body.get("scope_id")==scope else R.fail("Unauthorized","ref")
	func bind() -> void:
		scope=game.query("campaign").value.world_id
		session=game.query().value.session_id
	func msg(id: String, name: String, args: Dictionary) -> Dictionary:
		return {"command_id":id,"scope_id":scope,"actor_ref":"player","expected_revision":game.query("campaign").value.revision,
			"issued_tick":null,"sequence":null,"payload":{"type":"character."+name,"args":args}}
	func view() -> Dictionary: return game.query("character",{"context":principal}).value

func verify(ok: bool, text: String) -> bool:
	checks+=1
	if not ok:
		failures.append(text)
		printerr("FAIL ",text)
	return ok

func probe() -> void:
	var dir: String=OS.get_environment("GOV_REVIEW_STORAGE")
	var slot: String=Crypto.new().generate_random_bytes(6).hex_encode()
	var a:=Client.new(dir,slot)
	var b:=Client.new(dir,slot)
	if not verify(a.game.start_session("sandbox",F.options(slot)).ok,"A starts disk-backed game"):return
	a.bind()
	if not verify(a.game.dispatch(a.msg("create","create",{}),a.principal).ok and a.game.dispatch(a.msg("open","governor_open",{}),a.principal).ok,"A saves estate"):return
	if not verify(b.game.load_session(slot,F.CONTENT).ok,"B opens same disk checkpoint"):return
	b.bind()
	var before: Dictionary=b.view()
	var request:=a.msg("install","governor_assign",{"hero_id":before.heirs[0].id,"settlement_id":before.governance.settlement_id})
	var ack: Dictionary=a.game.dispatch(request,a.principal)
	if not verify(ack.ok,"A names incumbent"):return
	var wrong: Dictionary=b.game.dispatch(b.msg("old-planner","rest",{}),b.principal)
	verify(not wrong.ok and b.view()==before,"stale writer cannot advance the vacant-office day over A's appointment")
	var c:=Client.new(dir,slot)
	if not verify(c.game.load_session(slot,F.CONTENT).ok,"third independent loader reads winner"):return
	c.bind()
	verify(c.view().governance==a.view().governance and c.view().governance.governor_id==before.heirs[0].id,"persisted incumbent belongs to A")
	verify(not c.game.dispatch(request,a.principal).ok and c.game.dispatch(request,c.principal)==ack,"historic replay still checks the current session token")
	var rest:=c.msg("published-day","rest",{})
	if not verify(c.game.dispatch(rest,c.principal).ok,"third session spends one day"):return
	var frozen: Dictionary=c.view()
	var stale: Dictionary=a.game.dispatch(a.msg("old-dismiss","governor_dismiss",{"settlement_id":before.governance.settlement_id}),a.principal)
	verify(not stale.ok and a.view().governance.governor_id==before.heirs[0].id,"prior winning A cannot revert newer committed day")
	var d:=Client.new(dir,slot)
	if not verify(d.game.load_session(slot,F.CONTENT).ok,"fourth independent reader"):return
	d.bind()
	verify(d.view()==frozen and d.game.dispatch(rest,d.principal).ok and d.view()==frozen,"all users see the same committed term and day, replay awards nothing")

func _initialize() -> void:
	probe()
	print("P4_REVIEW ",JSON.stringify({"case":"four_sessions_contending_for_one_estate","checks":checks,"failures":failures}))
	quit(int(checks!=12 or not failures.is_empty()))
