from pathlib import Path
import hashlib,json,os,subprocess,sys
root=Path(__file__).resolve().parents[3]
out=root/'out/p4/root/pack'
out.mkdir(parents=True,exist_ok=True)
cwd=out/'empty'
cwd.mkdir(exist_ok=True)
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','RECOLLECTION_GOVERNOR_CAPTURES'):
 path=out/key
 path.mkdir(exist_ok=True)
 env[key]=str(path)
pck=next((root/'out/p4/build').glob('*/client.pck'))
manifest=json.loads((pck.parent/'manifest.json').read_text('utf8'))
for name,info in manifest['artifacts'].items():
 value=(pck.parent/name).read_bytes()
 assert len(value)==info['size'] and hashlib.sha256(value).hexdigest()==info['sha256']
# The external test driver opens only the scenes and services in the supplied PCK.
engine='D:/Program/Godot/Standard/Godot_v4.7.2-stable_win64_console.exe'
args=[engine,'--windowed','--resolution','960x600','--log-file',str(out/'engine.log'),'--main-pack',str(pck),'--script',str(root/'out/p4/root/cold/game/tests/p4/governor_desktop/run.gd'),'--','--profile=client']
p=subprocess.run(args,cwd=cwd,env=env,capture_output=True,timeout=120)
log=(p.stdout+p.stderr).decode('utf8','replace');(out/'console.log').write_text(log,encoding='utf8')
ok=p.returncode==0 and 'checks=73 failures=0' in log and 'SCRIPT ERROR' not in log and 'ERROR:' not in log
summary={'engine_exit':p.returncode,'status':'PASS' if ok else 'FAIL','args':args,'game_commit':manifest['git_commit'],'sha256':manifest['artifacts']['client.pck']['sha256'],'summary':log.splitlines()[-1]}
(out/'result.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
print(log)
sys.exit(0 if ok else 1)
