extends SceneTree
const Boot = preload("res://bootstrap/composition_root.gd")
const Config = preload("res://bootstrap/boot_config.gd")
const Store = preload("res://infrastructure/persistence/save_service.gd")
const App = preload("res://application/game_session.gd")
const Camp = preload("res://campaign/runtime.gd")
const Canon = preload("res://contracts/canonical.gd")
const R = preload("res://contracts/result.gd")
const SLOT := "legacyfamily"
const FOREIGN := "hero/00000000-0000-4000-8000-0000000000aa"
const FOREIGN_FIEF := "settlement/00000000-0000-4000-8000-0000000000aa"
const PARTY := "party/00000000-0000-4000-8000-0000000000aa"
var checks := 0
var failures := 0
var store := Store.new()
var app: RefCounted
var player := RefCounted.new()
var authority := RefCounted.new()
var world := ""
var session_id := ""
var founder := ""
var heir := ""
var fief := ""
var original := {}
var content := {}

func ck(ok: bool, label: String) -> bool:
	checks += 1
	if ok:
		print("PASS ", label)
	else:
		printerr("FAIL ", label)
		failures += 1
	return ok

func _initialize() -> void:
	run.call_deferred()

func snapshot() -> Dictionary:
	return store.recover(SLOT).value.snapshot

func view() -> Dictionary:
	return app.query("character", {"context":player}).value

func permit(token: Variant, op: String, req: Dictionary) -> Dictionary:
	if req.get("scope_id") != world or req.get("session_id") != session_id:
		return R.fail("Unauthorized","session")
	if is_same(token, player):
		return R.ok("player")
	if is_same(token, authority) and op == "character.outcome":
		return R.ok("character.authority")
	return R.fail("Unauthorized", "qa_identity")

func bind() -> void:
	player = RefCounted.new()
	session_id = app.query().value.session_id

func envelope(id: String, action: String, args: Dictionary, actor: String="player") -> Dictionary:
	return {"command_id":id,"actor_ref":actor,"scope_id":world,"expected_revision":view().revision,
		"issued_tick":null,"sequence":null,"payload":{"type":"character."+action,"args":args}}

func cmd(id: String, action: String, args: Dictionary={}) -> Dictionary:
	return app.dispatch(envelope(id, action, args), player)

func outcome(id: String, kind: String, hero: String, extra: Dictionary={}) -> Dictionary:
	var payload := {"source":id,"hero_id":hero,"kind":kind}
	payload.merge(extra)
	return app.dispatch(envelope(id,"outcome",payload,"character.authority"), authority)

func candidate(id: String) -> Dictionary:
	for row in view().governance.candidates:
		if row.id == id:
			return row
	return {}

func cold() -> bool:
	var expected := view()
	var retired_token := player
	var next: RefCounted = App.new(store,func(): return Camp.new(),Callable(),permit)
	if not ck(app.close_session().ok and next.load_session(SLOT,content).ok, "close and reload real store into fresh application"):
		return false
	app = next
	bind()
	return ck(view() == expected and not app.query("character",{"context":retired_token}).ok, "exact cold projection and fresh authority token")

func run() -> void:
	original = snapshot()
	content = {"content_hash":original.content_hash,"packages":original.content_packages}
	world = original.world_id
	var boot = Boot.new(root)
	var cfg := Config.resolve([],DisplayServer.get_name(),{})
	if ck(boot.boot(cfg.value).ok and boot.load_world(SLOT).ok,"production BOOT opens archived P3 family"):
		boot_path(boot)
	boot.shutdown()
	if failures == 0:
		app = App.new(store,func(): return Camp.new(),Callable(),permit)
		if ck(app.load_session(SLOT,content).ok,"real application opens physical slot with injected authority transport"):
			bind()
			transaction_path()
		app.close_session()
	print("GOVERNOR_INDEPENDENT checks=%d failures=%d" % [checks,failures])
	quit(int(failures > 0))

func boot_path(boot: RefCounted) -> void:
	var old: Dictionary = boot.character_view().value
	if not ck(old.has("governance"), "legacy projection exposes governance"):
		return
	founder = old.player_id
	heir = old.heirs[0].id
	ck(old.day==4 and old.family.size()==2 and old.governance.established==false,"old day four and existing family, land still unopened")
	ck(not snapshot().campaign.has("governance") and original==snapshot(),"loading never silently rewrites the old snapshot")
	var id := "qa-open"
	var opened: Dictionary = boot.character_command("governor_open",{},old.revision,id)
	if not ck(opened.ok,"public gameplay command opens original family holding"):
		return
	var fresh: Dictionary = boot.character_view().value
	var g: Dictionary = fresh.governance
	fief = g.settlement_id
	ck(Canon.encode(fresh).ok and g.established and g.name=="柳溪庄", "canonical Chinese governance projection")
	ck(g.owner_clan_id == original.campaign.characters.household.id and fief.begins_with("settlement/"),"typed holding belongs to the actual old household")
	ck(g.last_day==4 and g.last_report.is_empty() and g.prosperity==500 and g.loyalty==500,"no retroactive income or reports")
	ck(g.governor_id==null and g.can_manage, "starts vacant and manageable")
	ck(boot.character_command("governor_open",{},old.revision,id)==opened and boot.character_view().value==fresh,"BOOT idempotent open replays original receipt")
	ck(not boot.character_command("governor_open",{},fresh.revision,"qa-open-again").ok,"fresh duplicate establishment rejected")
	ck(not boot.character_command("outcome",{},fresh.revision,"qa-fake").ok,"bootstrap denies trusted outcome to player")
	ck(snapshot().campaign.inventory==original.campaign.inventory and snapshot().campaign.characters==original.campaign.characters,"opening leaves items and legacy heroes intact")

func transaction_path() -> void:
	if not ck(cold(), "governance survived stage change and real save"):
		return
	var selection := {"settlement_id":fief,"hero_id":heir}
	var assign := envelope("qa-assign","governor_assign",selection)
	var before := snapshot()
	ck(not app.dispatch(assign,RefCounted.new()).ok, "arbitrary token rejected")
	var stale := assign.duplicate(true)
	stale.expected_revision -= 1
	ck(not app.dispatch(stale,player).ok, "stale revision rejected")
	stale = assign.duplicate(true)
	stale.scope_id = "world/wrong"
	ck(not app.dispatch(stale,player).ok, "foreign world rejected")
	ck(not cmd("qa-foreign","governor_assign",{"settlement_id":fief,"hero_id":FOREIGN}).ok and not cmd("qa-wrong-place","governor_assign",{"settlement_id":FOREIGN_FIEF,"hero_id":heir}).ok, "foreign people and holding rejected")
	ck(not candidate(founder).eligible and not candidate(founder).reason.is_empty() and not cmd("qa-self","governor_assign",{"settlement_id":fief,"hero_id":founder}).ok, "household head cannot occupy office")
	ck(candidate(heir).eligible,"actual adult household member is eligible")
	ck(snapshot()==before and view().governance.governor_id==null,"invalid writes do not publish a revision or partial appointment")
	if not ck(cmd("qa-vacant-day","rest").ok,"advance a day without a governor"):
		return
	var vacant: Dictionary = view().governance
	ck(vacant.last_day==5 and vacant.prosperity==501 and vacant.loyalty==499 and vacant.last_report.governor_id==null, "vacant day baseline changes real totals")
	ck(vacant.last_report.prosperity_bonus==0 and vacant.last_report.loyalty_bonus==0,"no governor contributes zero")
	assign = envelope("qa-appointed","governor_assign",selection)
	before = snapshot()
	store.fault_point="partial_world"
	ck(not app.dispatch(assign,player).ok,"real interrupted disk write refuses appointment")
	store.fault_point=""
	ck(snapshot()==before and view().governance==vacant, "disk and live state both preserve vacancy on failure")
	var receipt: Dictionary=app.dispatch(assign,player)
	if not ck(receipt.ok and view().governance.governor_id==heir,"retry same pending assignment commits once"):
		return
	ck(app.dispatch(assign,player)==receipt,"durable appointment replay")
	var conflicting := assign.duplicate(true)
	conflicting.payload.args.hero_id=founder
	ck(not app.dispatch(conflicting,player).ok,"same request ID conflicting body rejected")
	if not cold():
		return
	ck(app.dispatch(assign,player)==receipt,"appointment receipt survives a cold load")
	var around: Dictionary = snapshot().campaign
	var guard := Camp.new()
	if not ck(guard.restore(around).ok,"load independent campaign copy at assignment"): return
	var reserve := [{"hero_id":heir,"count":1}]
	ck(not guard.check_character_sources(reserve).ok and guard.check_character_sources([{"hero_id":founder,"count":1}]).ok,"serving governor cannot fill an expedition slot, another healthy household member can")
	var stats := candidate(heir)
	var day := envelope("qa-paid-day","rest",{})
	store.fault_point="after_marker"
	ck(not app.dispatch(day,player).ok,"interrupted acknowledgement reported")
	store.fault_point=""
	var paid: Dictionary=view().governance
	if not ck(paid.last_day==6 and paid.last_report.governor_id==heir,"physical post-marker commit recovered with one daily report"):
		return
	ck(paid.last_report.prosperity_bonus==1+stats.stewardship and paid.last_report.loyalty_bonus==1+stats.leadership,"reported governor effects equal the member's actual two skills")
	ck(paid.prosperity==vacant.prosperity+1+paid.last_report.prosperity_bonus and paid.loyalty==vacant.loyalty-1+paid.last_report.loyalty_bonus,"actual prosperity and loyalty include the governor")
	var retry: Dictionary=app.dispatch(day,player)
	ck(retry.ok and view().governance==paid,"ambiguous ACK retry never pays a second day")
	print("GOV_FIRST_EFFECT ",JSON.stringify({"vacant":vacant.last_report,"appointed":paid.last_report}))
	if not cold():
		return
	ck(app.dispatch(day,player)==retry and view().governance==paid,"daily receipt persists cold")
	if not ck(outcome("qa-administrative-work","skill",heir,{"skill":"stewardship","amount":1000}).ok,"accepted work event improves a serving governor's management"):
		return
	var experienced := candidate(heir)
	ck(experienced.stewardship>stats.stewardship and experienced.leadership==stats.leadership, "only the trained skill increases")
	ck(view().governance.last_report==paid.last_report,"training never rewrites yesterday's report")
	if not ck(cmd("qa-skilled-day","rest").ok,"advance actual campaign with a more skilled incumbent"): return
	var skilled: Dictionary=view().governance
	ck(skilled.last_report.prosperity_bonus==1+experienced.stewardship and skilled.last_report.prosperity_bonus>paid.last_report.prosperity_bonus and skilled.prosperity-paid.prosperity>paid.prosperity-vacant.prosperity,"same person, improved skill, measurably higher daily growth")
	ck(outcome("qa-founder-held","capture",founder,{"location":PARTY}).ok and not view().governance.can_manage and view().governance.governor_id==heir,"captive lord loses management power; healthy incumbent remains")
	ck(not cmd("qa-false-dismiss","governor_dismiss",{"settlement_id":fief}).ok,"captured head cannot dismiss the governor")
	ck(outcome("qa-founder-free","release",founder).ok and view().governance.can_manage,"released head can manage again")
	ck(outcome("qa-governor-departs","join",heir,{"location":PARTY}).ok and view().governance.governor_id==null and not candidate(heir).eligible,"governor transferring to travelling party vacates office")
	ck(outcome("qa-governor-back","leave",heir,{"location":"character:place/home"}).ok and candidate(heir).eligible and view().governance.governor_id==null,"returning home does not reclaim an old posting")
	if not ck(cmd("qa-after-return","governor_assign",selection).ok,"explicit appointment after return"): return
	if not ck(outcome("qa-wound","wound",heir,{"severity":10}).ok and view().governance.governor_id==heir,"light wound preserves the office"): return
	if not ck(cmd("qa-dismiss","governor_dismiss",{"settlement_id":fief}).ok,"explicit dismissal"): return
	ck(view().governance.governor_id==null and view().governance.last_report==skilled.last_report,"vacancy preserves old signed daily report")
	if not ck(cmd("qa-reappoint","governor_assign",selection).ok,"wounded but home, appointment remains legal"): return
	before = snapshot()
	store.fault_point="before_marker"
	ck(not outcome("qa-capture","capture",heir,{"location":PARTY}).ok and view().governance.governor_id==heir,"failed capture cannot dislodge live governor")
	store.fault_point=""
	ck(snapshot()==before,"failed cross-domain write also preserves disk")
	if not ck(outcome("qa-capture","capture",heir,{"location":PARTY}).ok,"retry capture succeeds"): return
	ck(view().governance.governor_id==null and not candidate(heir).eligible and not candidate(heir).reason.is_empty(),"real captivity vacates office and rejects selection")
	ck(not cmd("qa-captive-assign","governor_assign",selection).ok and view().governance.last_report==skilled.last_report,"new appointment denied; prior day's governor remains historically correct")
	if not cold(): return
	ck(outcome("qa-release","release",heir).ok and candidate(heir).eligible and view().governance.governor_id==null, "release restores eligibility without restoring tenure")
	if not ck(cmd("qa-reappoint-release","governor_assign",selection).ok,"reappoint released member"): return
	var dump := snapshot()
	for tamper in [null,{},{"schema_version":99}]:
		var bad: Dictionary=dump.campaign.duplicate(true)
		bad.governance=tamper
		ck(not Camp.new().restore(bad).ok,"malformed explicit or future governor repository refused")
	var bad_day: Dictionary=dump.campaign.duplicate(true)
	bad_day.governance.last_day+=1
	ck(not Camp.new().restore(bad_day).ok,"future day cursor refused")
	var bad_hero: Dictionary=dump.campaign.duplicate(true)
	bad_hero.governance.governor_id=FOREIGN
	ck(not Camp.new().restore(bad_hero).ok,"orphaned governor refused")
	if not ck(cmd("qa-retire","retire",{"heir_id":heir}).ok,"serving governor inherits household"): return
	ck(view().player_id==heir and view().governance.governor_id==null and view().governance.owner_clan_id==original.campaign.characters.household.id,"heir promoted, office vacated, same household owns the holding")
	ck(view().governance.last_report==skilled.last_report and not candidate(heir).eligible,"historic report retained after succession and new head no longer eligible")
	if not cold(): return
	var after := snapshot()
	ck(after.world_id==original.world_id and after.content_hash==original.content_hash,"world identity and content hash survive migration")
	for key in original.session.commands:
		ck(after.session.commands.get(key)==original.session.commands[key],"old gameplay receipt preserved")
	print("GOV_EFFECT ",JSON.stringify({"vacant":vacant.last_report,"appointed":paid.last_report,"trained":skilled.last_report}))
