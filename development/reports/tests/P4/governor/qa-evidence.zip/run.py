"""Run one opt-in probe against an isolated source tree or a packaged game."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import zipfile

HERE = Path(__file__).resolve().parent
ENGINE = Path("D:/Program/Godot/Standard/Godot_v4.7.2-stable_win64_console.exe")
p = argparse.ArgumentParser()
p.add_argument("label")
p.add_argument("game", type=Path)
p.add_argument("script")
p.add_argument("--old", action="store_true", help="Copy the archived real P3 save into a new profile.")
p.add_argument("--desktop", action="store_true")
p.add_argument("--profile")
args = p.parse_args()
game = args.game.resolve()
label = args.label
profile = HERE / "profiles" / (args.profile or label)
profile.mkdir(parents=True, exist_ok=True)
empty = HERE / "empty-cwd"
empty.mkdir(exist_ok=True)
assert not list(empty.iterdir())
pack = game.suffix == ".pck"
if args.old:
    save = profile / "Godot/app_userdata/recollection/saves/legacyfamily"
    assert not save.exists(), f"Choose a fresh profile: {save}"
    with zipfile.ZipFile(HERE / "legacy-save.zip") as archive:
        archive.extractall(profile / "Godot/app_userdata/recollection/saves")
cmd = [str(ENGINE), *(["--windowed", "--resolution", "1280x800"] if args.desktop else ["--headless"])]
cmd += ["--main-pack" if pack else "--path", str(game), "--log-file", str(HERE / (label + "-engine.log"))]
if args.script == "import":
    cmd += ["--editor", "--import"]
else:
    cmd += ["--script", args.script if args.script.startswith("res://") else str(HERE / args.script)]
env = dict(os.environ, APPDATA=str(profile), LOCALAPPDATA=str(profile))
env["GOV_QA_ROOT"] = str(HERE.resolve()).replace("\\", "/")
result = subprocess.run(cmd, cwd=empty, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=180)
raw = result.stdout
(HERE / (label + ".log")).write_bytes(raw)
log = raw.decode("utf-8", "replace")
counts = re.findall(r"checks=(\d+) failures=(\d+)", log)
bad = any(marker in log for marker in ["SCRIPT ERROR:", "ERROR:", "\nFAIL "])
data = dict(command=cmd, cwd=str(empty), profile=str(profile), exit_code=result.returncode,
            error_output=bad, stdout_sha256=hashlib.sha256(raw).hexdigest(), counts=counts)
if pack:
    data["pack_sha256"] = hashlib.sha256(game.read_bytes()).hexdigest()
if args.script in ("probe.gd", "legacy.gd") and not counts:
    bad = True
data["status"] = "PASS" if not bad and not result.returncode else "FAIL"
(HERE / (label + ".json")).write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(label, data["status"], result.returncode, log[-1700:])
raise SystemExit(0 if data["status"] == "PASS" else 1)
