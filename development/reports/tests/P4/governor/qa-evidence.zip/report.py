"""Recount from immutable process stdout, verify the certified PCK, and archive evidence."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

q = Path(__file__).resolve().parent
repo = q.parents[2]
build = repo / "out/p4/build/0ca0100bd8ef-53340a024091"
manifest = json.loads((build/"manifest.json").read_bytes())
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert digest(build/"client.pck") == manifest["artifacts"]["client.pck"]["sha256"]
groups = {
    "old_client": ["legacy-family"],
    "cold_source": ["source-governance","source-governor_facts","source-governor_campaign",
                    "source-governor_session","source-desktop-repeat","integrated-behavior"],
    "production_client": ["pack-behavior","pack-desktop"],
    "superseded": ["source-desktop"],
}
rows = []
for group, labels in groups.items():
    for label in labels:
        log = (q/(label+".log")).read_text("utf8",errors="replace")
        meta = json.loads((q/(label+".json")).read_bytes())
        assert digest(q/(label+".log")) == meta["stdout_sha256"]
        count = re.search(r"checks=(\d+) failures=(\d+)",log)
        if count:
            checks, failures = map(int,count.groups())
        else:
            count = re.search(r"(\d+)/(\d+) failures=(\d+)",log)
            passed, checks, failures = map(int,count.groups())
            assert checks == passed + failures
        assert (group=="superseded") == (failures > 0)
        assert (meta["exit_code"]==0) == (group!="superseded")
        if group=="production_client":
            assert meta["pack_sha256"] == manifest["artifacts"]["client.pck"]["sha256"]
        rows.append({"label":label,"group":group,"checks":checks,"failed":failures,
                     "passed":checks-failures,"exit_code":meta["exit_code"],"status":meta["status"],
                     "process_file":label+".json","stdout_file":label+".log"})
def stdout_json(name, tag):
    return json.loads(next(x for x in (q/(name+".log")).read_text("utf8",errors="replace").splitlines() if x.startswith(tag+" "))[len(tag)+1:])
report = {
    "task":"P4-GOV-QA", "status":"PASS", "test_ids":["T-GOV-01","T-GOV-02"],
    "old_build":"5e1ad4c39e7362b8b3a4b86f50405b279c35086c",
    "old_save_sha256":digest(q/"legacy-save.zip"),"old_archive":stdout_json("legacy-family","P3_ARCHIVE"),
    "game_commit":manifest["git_commit"],"engine":manifest["engine_version"],
    "client_sha256":manifest["artifacts"]["client.pck"]["sha256"],
    "renderer":"Windows · Vulkan 1.4.325 Forward+ · NVIDIA GeForce RTX 3090",
    "results":rows,
    "checks_by_group":{g:sum(r["checks"] for r in rows if r["group"]==g) for g in groups},
    "daily_results":stdout_json("pack-behavior","GOV_EFFECT"),
    "scope":"家族人物资格、实际任免、日结与技能、旧档、原子性、资格失效与传承。真实 Windows 窗口中的鼠标和键盘输入、日结预览和实结、存储、读回、继任以及无继任者界面亦已执行。",
    "source":"Git 冷归档 0ca0100，4 个域套件、桌面套件及独立旧档故障探针。旧存档来自真实 5e1ad4c 运行时。正式 PCK 由单独进程在空工作目录启动，使用独立用户目录，项目测试代码从包外传入。",
    "fixture":"正式 BOOT 创建/打开旧档及领地。异常分支以独立测试 principal 注入真实 GameSession、Campaign 与 SaveService 来发出受信战果意图并触发已有写盘故障点。客户端真实入口没有可向人物添加经验的 QA 接口。",
    "prior_failure":"首次源码窗口 72/73，指定截图目录不存在，PNG 保存失败；其余 72 项通过。QA 创建输出目录，在新用户目录按相同判据复跑 73/73。两次均记录真实退出码。",
    "checks_excluded_from_totals":["同一用例在源码、正式包有重叠；不同组的断言不可解释为唯一场景数。","前置开发树试组合 85/85 没有计入冷源码或成品数字。"],
    "not_run":["真人手柄、屏幕朗读、主观试玩","P2 大规模实时战斗性能","完整 P4 领地财政、建设、围攻及 P3/P4 整体门禁"],
    "reproduction":[
        "用 git archive <old_build> -- game 还原 P3，并在新目录用 run.py old-import <old-game> import --profile old 和 run.py legacy-family <old-game> legacy.gd --profile old 生成存档。",
        "证据内 legacy-save.zip 是相同 P3 软件实际写出的未修改存档。将 run.py、probe.gd、legacy-save.zip 放在同一目录，然后执行 python run.py pack-check <client.pck绝对路径> probe.gd --old。选择新的 label 即采用新的用户目录。",
        "先创建截图目录并设置 RECOLLECTION_GOVERNOR_CAPTURES，再执行 python run.py pack-window <client.pck绝对路径> client_desktop.gd --desktop。每次运行以命名 JSON 与原始日志进行核验。",
    ],
}
(q/"summary.json").write_text(json.dumps(report,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
names=["run.py","probe.gd","client_desktop.gd","legacy.gd","report.py","summary.json","legacy-save.zip",
       "captures-source/governor.png","captures-pack/governor.png"]
for label in ["legacy-import","integrated-import","preflight-behavior",*(r["label"] for r in rows)]:
    names.extend(label+suffix for suffix in [".json",".log","-engine.log"])
with zipfile.ZipFile(q/"qa-evidence.zip","w",zipfile.ZIP_DEFLATED) as z:
    for name in names:
        z.write(q/name,name)
with zipfile.ZipFile(q/"qa-evidence.zip") as z:
    assert z.testzip() is None
print(report["checks_by_group"],"evidence SHA-256",digest(q/"qa-evidence.zip"))
