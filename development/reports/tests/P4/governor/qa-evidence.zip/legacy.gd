extends SceneTree
const Boot = preload("res://bootstrap/composition_root.gd")
const Config = preload("res://bootstrap/boot_config.gd")
const Store = preload("res://infrastructure/persistence/save_service.gd")
const Canon = preload("res://contracts/canonical.gd")
const SLOT := "legacyfamily"
var checks := 0
var failures := 0

func ck(ok: bool, message: String) -> bool:
	checks += 1
	if not ok:
		failures += 1
		printerr("FAIL ", message)
	return ok

func _initialize() -> void:
	run.call_deferred()

func run() -> void:
	var boot = Boot.new(root)
	var cfg := Config.resolve([], DisplayServer.get_name(), {})
	if ck(cfg.ok and boot.boot(cfg.value).ok, "cold P3 production bootstrap") and ck(boot.new_world(SLOT).ok, "normal sandbox"):
		var model: Dictionary = boot.character_view().value
		if ck(boot.character_command("create", {"name":"梓青","culture":"river"}, model.revision, "legacy-founder").ok, "found a household"):
			for i in 4:
				model = boot.character_view().value
				ck(boot.character_command("rest", {}, model.revision, "legacy-rest-%d"%i).ok, "advance old campaign")
			model = boot.character_view().value
			var saved: Dictionary = Store.new().recover(SLOT).value.snapshot
			ck(model.day == 4 and model.family.size() == 2 and model.heirs.size() == 1, "family can continue")
			ck(not model.has("governance") and not saved.campaign.has("governance"), "old build has no governor")
			ck(saved.session.commands.size() == 5 and saved.campaign.has("inventory"), "real durable commands and existing goods")
			print("P3_ARCHIVE ", JSON.stringify({"world":saved.world_id,"clan":saved.campaign.characters.household.id,
				"hero":model.player_id,"heir":model.heirs[0].id,"day":model.day,"minute":saved.game_minute,
				"content_hash":saved.content_hash, "items_hash":Canon.hash_value(saved.campaign.inventory).value,
				"commands_hash":Canon.hash_value(saved.session.commands).value}))
	boot.shutdown()
	print("LEGACY_GOV checks=%d failures=%d"%[checks,failures])
	quit(int(failures > 0))
