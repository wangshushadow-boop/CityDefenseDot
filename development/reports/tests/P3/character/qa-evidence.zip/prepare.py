import sys,subprocess,os,shutil,pathlib,zipfile,io
q=pathlib.Path(__file__).resolve().parent
root=q.parents[2]
action=sys.argv[1]
if action=='candidate':
 dst=q/'candidate/game'
 shutil.copytree(root/'out/p3/joined/game',dst,dirs_exist_ok=True,ignore=shutil.ignore_patterns('.godot','*.uid','*.import'))
 print(dst)
elif action=='profile':
 source=q/'profiles/legacy/Godot/app_userdata/recollection/saves'
 dst=q/'profiles'/sys.argv[2]/'Godot/app_userdata/recollection/saves'
 assert not dst.exists()
 shutil.copytree(source,dst)
elif action=='archive':
 ref=sys.argv[2];dst=q/sys.argv[3]
 assert not dst.exists()
 with zipfile.ZipFile(io.BytesIO(subprocess.check_output(['git','archive','--format=zip',ref,'game'],cwd=root))) as z:z.extractall(dst)
 print(subprocess.check_output(['git','rev-parse',ref],cwd=root).decode().strip())
