from pathlib import Path
import shutil,sys,hashlib,json
q=Path(__file__).resolve().parent
root=q.parents[2]
dst=q/sys.argv[1]/'game'
if not dst.exists():shutil.copytree(q/'candidate/game',dst)
inputs=[('','.','campaign/character/ports/characters.gd'),('','.','campaign/clan/ports/character_household.gd'),('hero','.worktrees/p3-hero','campaign/character/hero_domain.gd'),('hero','.worktrees/p3-hero','campaign/character/hero_rules.json'),('gear','.worktrees/p3-gear','campaign/character/gear.gd'),('gear','.worktrees/p3-gear','shared/inventory/inventory.gd'),('runtime','.worktrees/p3-runtime','campaign/runtime.gd'),('runtime','.worktrees/p3-runtime','application/game_session.gd'),('desktop','.worktrees/p3-desktop','bootstrap/composition_root.gd'),('desktop','.worktrees/p3-desktop','bootstrap/desktop.gd'),('desktop','.worktrees/p3-desktop','presentation/ui/ports/character_panel.gd')]
hashes={}
for _,base,rel in inputs:
 s=root/base/'game'/rel
 t=dst/rel
 t.parent.mkdir(exist_ok=True,parents=True);shutil.copyfile(s,t)
 hashes[rel]=hashlib.sha256(t.read_bytes()).hexdigest()
(dst.parent/'inputs.json').write_text(json.dumps(hashes,indent=2)+'\n')
print('candidate',dst,len(hashes))
