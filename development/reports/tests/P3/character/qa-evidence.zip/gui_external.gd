extends SceneTree
## All character actions in this probe are pointer events sent through the real Window.
const Store=preload("res://infrastructure/persistence/save_service.gd")
var checks:=0
var failures:=0
func _initialize() -> void:
	go.call_deferred()
func go() -> void:
	var loaded=change_scene_to_file("res://bootstrap/main.tscn")
	if loaded!=OK:quit(2);return
	for i in 12:await process_frame
	await suite()
	print("PACK_GUI checks=%d failures=%d renderer=%s adapter=%s"%[checks,failures,RenderingServer.get_current_rendering_method(),RenderingServer.get_video_adapter_name()])
	quit(0 if failures==0 and checks>=21 else 1)
func check(ok: bool,s: String) -> bool:
	checks+=1
	if not ok:failures+=1;printerr("FAIL ",s)
	return ok
func find_button(title: String):
	for node in root.find_children("*","Button",true,false):
		if node.text==title and node.is_visible_in_tree() and not node.disabled:return node
	return null
func click(title: String) -> bool:
	var b=find_button(title)
	if not check(b!=null,"button present: "+title):return false
	var parent=b.get_parent()
	while parent!=null and not parent is ScrollContainer:parent=parent.get_parent()
	if parent!=null:parent.ensure_control_visible(b)
	for i in 3:await process_frame
	var point=b.get_global_rect().get_center()
	if not check(root.get_visible_rect().has_point(point),"inside viewport: "+title):return false
	var motion:=InputEventMouseMotion.new()
	motion.position=point
	motion.global_position=point
	root.push_input(motion,true)
	for down in [true,false]:
		var e:=InputEventMouseButton.new()
		e.button_index=MOUSE_BUTTON_LEFT
		e.position=point
		e.global_position=point
		e.pressed=down
		root.push_input(e,true)
	for i in 4:await process_frame
	return true
func suite() -> void:
	if not await click("新建沙盒"):return
	if not await click("人物"):return
	if not check(root.find_child("HeroName",true,false) is LineEdit,"real creation panel"):return
	if not await click("确立身世"):return
	if not await click("行装"):return
	if not await click("家人和继承"):return
	var st=Store.new()
	var saved=st.recover("campaign")
	if not check(saved.ok,"read disk from production save after gameplay"):return
	var repo=saved.value.snapshot.campaign.characters
	var id=repo.household.leader
	var item_count=saved.value.snapshot.campaign.inventory.state.owners.size()
	check(repo.heroes.size()==2 and item_count>2,"two persisted people and real items")
	if not await click("返回沙盒"):return
	if not await click("保存进度"):return
	if not await click("关闭会话"):return
	if not await click("读取存档"):return
	if not await click("人物"):return
	check(find_button("行装")!=null and find_button("家人和继承")!=null,"reloaded real character panel")
	var after=st.recover("campaign").value.snapshot.campaign
	check(after.characters.household.leader==id and after.inventory.state.owners.size()==item_count,"reloaded same hero and original gear")
	if not OS.get_environment("P3_QA_CAPTURE").is_empty():
		await RenderingServer.frame_post_draw
		var frame: Image=root.get_texture().get_image()
		check(frame!=null and frame.get_width()>=960 and frame.get_height()>=600 and frame.save_png(OS.get_environment("P3_QA_CAPTURE"))==OK,"captured rendered PCK output")
