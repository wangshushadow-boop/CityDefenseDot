extends SceneTree
const Boot=preload("res://bootstrap/composition_root.gd")
const Config=preload("res://bootstrap/boot_config.gd")
const C=preload("res://contracts/canonical.gd")
func _initialize() -> void:
	run.call_deferred()
func walk(x: Variant,p: String) -> void:
	if not C.encode(x).ok:
		print("NODE ",p," ",C.encode(x).get("error"))
	if x is Array:
		for i in x.size():walk(x[i],p+"/"+str(i))
	elif x is Dictionary:
		for k in x:
			if typeof(k)!=TYPE_STRING:print("NONSTRING_KEY ",p," ",str(k)," ",type_string(typeof(k)))
			walk(x[k],p+"/"+str(k))
	elif not C.encode(x).ok:
		print("NONCANONICAL ",p," ",type_string(typeof(x))," ",str(x)," ",C.encode(x))
func run() -> void:
	var b=Boot.new(root)
	if not b.boot(Config.resolve([],DisplayServer.get_name(),{}).value).ok or not b.load_world("oldgoods").ok:
		quit(1);return
	var m=b.character_view().value
	print("HERO_ENCODE ",C.encode(m.hero).ok)
	walk(m.hero,"hero")
	b.shutdown();quit()
