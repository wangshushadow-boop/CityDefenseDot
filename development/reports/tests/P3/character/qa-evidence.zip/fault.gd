extends SceneTree
const App=preload("res://application/game_session.gd")
const Camp=preload("res://campaign/runtime.gd")
const Store=preload("res://infrastructure/persistence/save_service.gd")
const C=preload("res://contracts/canonical.gd")
const R=preload("res://contracts/result.gd")
var owner=RefCounted.new()
var system=RefCounted.new()
var store=Store.new()
var session
var checks:=0
var failures:=0
var slot="oldgoods"
func _initialize() -> void:
	go.call_deferred()
func check(ok: bool,label: String) -> bool:
	checks+=1
	if not ok:
		printerr("FAIL ",label)
		failures+=1
	return ok
func permit(token: Variant,op: String,_req: Dictionary) -> Dictionary:
	if token==owner and op in ["character.view","character.create","character.equip","character.retire","character.rest","character.practice"]:
		return R.ok("player")
	if token==system and op=="character.outcome":return R.ok("character.authority")
	return R.fail("Unauthorized","qa")
func view() -> Dictionary:
	return session.query("character",{"context":owner}).value
func envelope(kind: String,args: Dictionary,id: String,actor: String="player") -> Dictionary:
	var v=view()
	return {"command_id":id,"actor_ref":actor,"scope_id":v.world_id,"expected_revision":v.revision,"issued_tick":null,"sequence":null,"payload":{"type":"character."+kind,"args":args}}
func snapshot() -> Dictionary:
	return store.recover(slot).value.snapshot
func go() -> void:
	var saved:=snapshot()
	var content={"content_hash":saved.content_hash,"packages":saved.content_packages}
	session=App.new(store,func():return Camp.new(),Callable(),permit)
	if check(session.load_session(slot,content).ok,"load legacy through actual App, Camp, Save"):
		actions()
	print("DURABLE_QA checks=%d failures=%d"%[checks,failures])
	session.close_session()
	quit(0 if failures==0 and checks>=28 else 1)
func actions() -> void:
	var initial:=view()
	var before:=snapshot()
	var create:=envelope("create",{},"genesis")
	store.fault_point="partial_world"
	var refused=session.dispatch(create,owner)
	if not check(not refused.ok and refused.error.code=="Unavailable","refuse truncated new payload"):return
	check(view()==initial and snapshot()==before,"failed genesis preserves all character, inventory and storage facts")
	store.fault_point=""
	if not check(session.dispatch(create,owner).ok,"retry same ID publishes genesis"):return
	check(snapshot().campaign.inventory.state.owners["p2-ancestral-talisman"]=="oldbag","old item intact")
	var start:=view()
	var id=start.player_id
	var heir=start.heirs[0].id
	var borrowed=RefCounted.new()
	var equip_args:Dictionary={}
	for i in start.gear.bag:
		for opt in i.options:
			if opt.allowed:
				equip_args={"profile":opt.profile,"slot":opt.slot,"item_id":i.item_id}
				break
		if not equip_args.is_empty():break
	if not check(not equip_args.is_empty(),"real exchange available"):return
	var equip:=envelope("equip",equip_args,"change-gear")
	before=snapshot()
	check(not session.dispatch(equip,borrowed).ok and snapshot()==before,"foreign principal cannot wear item")
	store.fault_point="before_write"
	var error=session.dispatch(equip,owner)
	check(not error.ok and error.error.code=="Unavailable","real disk failure after candidate INV exchange")
	check(view()==start and snapshot()==before,"aborted exchange retains owner, slot, version, receipt, disk")
	store.fault_point=""
	var ack=session.dispatch(equip,owner)
	if not check(ack.ok,"retry equip accepted"):return
	check(session.dispatch(equip,owner)==ack,"repeat same equipment command")
	check(view().gear.profiles[equip_args.profile][equip_args.slot]==equip_args.item_id,"new gear in expected profile slot")
	var outcome:=envelope("outcome",{"hero_id":id,"source":"real/world/event-1","kind":"wound","severity":28},"no-fabrication","character.authority")
	check(not session.dispatch(outcome,owner).ok,"player cannot grant authoritative wound")
	if not check(session.dispatch(outcome,system).ok,"system wound"):return
	var health=view().hero.wounds
	outcome=envelope("outcome",outcome.payload.args,"separate-delivery","character.authority")
	check(session.dispatch(outcome,system).ok and view().hero.wounds==health,"same game result different transport delivery")
	var seize:=envelope("outcome",{"hero_id":id,"source":"real/world/event-2","kind":"capture","location":"party/01234567-89ab-4cde-8123-456789abcdef"},"capture","character.authority")
	if not check(session.dispatch(seize,system).ok,"capture wounded"):return
	check(view().hero.wounds==health and view().hero.life_status=="Captive","wound and capture independent")
	check(not session.dispatch(envelope("retire",{"heir_id":heir},"escape"),owner).ok,"captive may not escape by retirement")
	var rest:=envelope("rest",{},"one-day")
	before=snapshot()
	store.fault_point="partial_world"
	check(not session.dispatch(rest,owner).ok and snapshot()==before and view().hero.wounds==health,"recovery candidate aborted to exact old day and HP")
	store.fault_point=""
	if not check(session.dispatch(rest,owner).ok,"advance full day including phase processing"):return
	check(view().hero.wounds<health and view().hero.life_status=="Captive" and view().game_minute==2870,"captive recovers exactly one day, clock matches old 1430")
	var healed:=view()
	check(session.dispatch(rest,owner).ok and view()==healed,"same day/retry no double heal")
	if not check(session.dispatch(envelope("outcome",{"hero_id":id,"kind":"release","source":"r3"},"release","character.authority"),system).ok,"release captive"):return
	var retire:=envelope("retire",{"heir_id":heir},"handover")
	var pre:=view()
	before=snapshot()
	store.fault_point="partial_world"
	check(not session.dispatch(retire,owner).ok and view()==pre and snapshot()==before,"failed succession changes neither controller nor assets")
	store.fault_point=""
	if not check(session.dispatch(retire,owner).ok,"succession retry succeeds"):return
	check(view().hero.id==heir and snapshot().campaign.characters.heroes[id].life_status=="Retired","player control rebound")
	check(snapshot().campaign.inventory.state.owners.size()==before.campaign.inventory.state.owners.size(),"unique item conservation")
	var post:=snapshot()
	check(session.dispatch(retire,owner).ok and snapshot()==post,"handover only once")
	check(not session.dispatch(envelope("outcome",{"hero_id":id,"kind":"join","location":"party/01234567-89ab-4cde-8123-456789abcdef","source":"invalid/return"},"reenter","character.authority"),system).ok and snapshot()==post,"terminal founder cannot rejoin")
