extends SceneTree
const Boot=preload("res://bootstrap/composition_root.gd")
const Config=preload("res://bootstrap/boot_config.gd")
const Store=preload("res://infrastructure/persistence/save_service.gd")
const C=preload("res://contracts/canonical.gd")
func _initialize() -> void:
	call_deferred("go")
func go() -> void:
	var b=Boot.new(root)
	var config:=Config.resolve([],DisplayServer.get_name(),{})
	if not config.ok or not b.boot(config.value).ok or not b.new_world("oldempty").ok:
		quit(1);return
	var s=Store.new()
	var old=s.recover("oldempty").value.snapshot
	if old.campaign.has("characters") or old.campaign.inventory!=null:
		quit(2);return
	var closed=b.session().close_session()
	var resource={"kind":"instance","id":"p2-ancestral-talisman"}
	var start={"game_minute":1430,"locations":{"oldbag":{"kind":"inventory","capacity":5},"oldshelf":{"kind":"inventory","capacity":3}},"initial":[{"holder":"oldbag","resource":resource,"amount":1}]}
	var content={"content_hash":old.content_hash,"packages":old.content_packages}
	var new_result=b.session().start_session("sandbox",{"slot":"oldgoods","seed":"1234567890abcdef","start_def":start,"content":content})
	if not closed.ok or not new_result.ok:
		print(new_result);quit(3);return
	var goods=s.recover("oldgoods").value.snapshot
	if goods.campaign.inventory.state.owners.get("p2-ancestral-talisman")!="oldbag" or goods.campaign.has("characters"):
		quit(4);return
	print("LEGACY ",JSON.stringify({"empty_world":old.world_id,"goods_world":goods.world_id,"hash":old.content_hash,"minute":goods.game_minute,"packages":goods.content_packages,"instance":"p2-ancestral-talisman","owner":"oldbag","legacy_inventory_sha":C.hash_value(goods.campaign.inventory).value}))
	b.shutdown()
	quit(0)
