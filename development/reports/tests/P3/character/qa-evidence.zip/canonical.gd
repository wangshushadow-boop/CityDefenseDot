extends SceneTree
const App=preload("res://application/game_session.gd")
const Camp=preload("res://campaign/runtime.gd")
const Store=preload("res://infrastructure/persistence/save_service.gd")
const Canon=preload("res://contracts/canonical.gd")
const R=preload("res://contracts/result.gd")
var store=Store.new()
var player=RefCounted.new()
var system=RefCounted.new()
var failures:=0
var checks:=0
var session
var issues:Dictionary
func allow(token:Variant,op:String,_req: Dictionary) -> Dictionary:
	if token==system and op=="character.outcome":return R.ok("character.authority")
	if token==player and op.begins_with("character."):return R.ok("player")
	return R.fail("Unauthorized","qa")
func _initialize() -> void:run.call_deferred()
func inspect(v: Variant,path:String) -> void:
	if v is Dictionary:
		for key in v:
			var child:=str(key)
			if path.ends_with("/skills") or path.ends_with("/items") or path.ends_with("/practice"):child="*"
			if typeof(key)!=TYPE_STRING:issues[path+"/"+child+" [key:"+type_string(typeof(key))+"]"]=true
			inspect(v[key],path+"/"+child)
	elif v is Array:
		for x in v:inspect(x,path+"/[]")
	elif not Canon.encode(v).ok:issues[path+" [value:"+type_string(typeof(v))+"]"]=true
func audit(label:String) -> void:
	var reply:Dictionary=session.query("character",{"context":player})
	issues={}
	inspect(reply.value,"view")
	var encoded:Dictionary=Canon.encode(reply.value)
	print("READ_MODEL ",label," canonical=",encoded.ok," issues=",JSON.stringify(issues.keys()))
	checks+=1
	if not encoded.ok or not issues.is_empty():failures+=1;return
	var decoded:Dictionary=Canon.decode(encoded.value)
	if not decoded.ok or decoded.value!=reply.value:failures+=1
func send(op:String,args:Dictionary,id:String,authority:=false) -> Dictionary:
	var view:Dictionary=session.query("character",{"context":player}).value
	return session.dispatch({"actor_ref":"character.authority" if authority else "player","scope_id":view.world_id,"command_id":id,"expected_revision":view.revision,"issued_tick":null,"sequence":null,"payload":{"type":"character."+op,"args":args}},system if authority else player)
func run() -> void:
	session=App.new(store,func():return Camp.new(),Callable(),allow)
	var snap:Dictionary=store.recover("oldgoods").value.snapshot
	if not session.load_session("oldgoods",{"content_hash":snap.content_hash,"packages":snap.content_packages}).ok:quit(3);return
	audit("before_create")
	if not send("create",{},"fixture-created").ok:quit(4);return
	audit("before_perk")
	var h:Dictionary=session.query("character",{"context":player}).value.hero
	if not send("outcome",{"hero_id":h.id,"kind":"skill","source":"qa-completed-activity","skill":"one_handed","amount":80},"fixture-xp",true).ok:quit(5);return
	if not send("perk",{"perk":"one_handed_hand"},"fixture-perk").ok:quit(6);return
	var v:Dictionary=session.query("character",{"context":player}).value
	if v.hero.effects.is_empty():quit(7);return
	audit("after_perk")
	session.close_session()
	print("PUBLIC_READMODEL checks=%d failures=%d"%[checks,failures])
	quit(0 if failures==0 and checks==3 else 1)
