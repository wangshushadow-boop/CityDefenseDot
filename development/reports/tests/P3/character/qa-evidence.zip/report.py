import sys,json,hashlib,zipfile,re,subprocess,pathlib
q=pathlib.Path(__file__).resolve().parent
root=q.parents[2]
def record(tag):
 v=json.loads((q/(tag+'.json')).read_text(encoding='utf8'))
 t=(q/(tag+'.log')).read_bytes().decode('utf8','replace').replace('\r','')
 return dict(v,marker=[r for r in t.splitlines() if 'checks=' in r or 'LEGACY {' in r or 'BOOT_DESKTOP' in r or 'DESKTOP' in r][-1:] or [],label=tag,log=tag+'.log')
names=['legacy-import','legacy-create','hero','gear-inventory','gear','flow','compatibility2','durable']
names+=[n for n in sys.argv[1:] if n not in names]
proof={ 'scope':'P3-CHR candidate/legacy/cold client independent verification',
 'p2_source':subprocess.check_output(['git','rev-parse','650adc4'],cwd=root,text=True).strip(),
 'engine':'4.7.2.stable.official.ed1daf0bf','mixed_candidate':'Frozen joined assembly at time of candidate extraction; final- labels use separate documented package/source provenance.',
 'status':'PASS' if all(record(x)['exit']==0 and not record(x)['error_output'] for x in names) else 'FAIL',
 'runs':[record(k) for k in names],
 'test_probe_history':['compatibility.log: QA probe attempted canonical hashing of the UI read model; received InvalidArgument. The old-save replay uses direct deep comparison. canonical-before.log then isolated 8 non-string keys in the public hero/equipment read model before/after a perk. canonical-revised.log repeats the identical whole-read-model encode/decode check on the corrected implementation in all three states.'],
 'not_run':['人工主观手感/无障碍','P2图形性能重测','完整战役遇敌/领地或任务继承，属后续包']}
for name in ['final-build','legacy-fact','package-provenance']:
 if (q/(name+'.json')).is_file():proof[name]=json.loads((q/(name+'.json')).read_text('utf8'))
(q/'results.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n','utf-8')
archive=q/'legacy-saves.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 old=q/'profiles/legacy/Godot/app_userdata/recollection/saves'
 for f in sorted(old.rglob('*')):
  if f.is_file():z.write(f,f.relative_to(old).as_posix())
with zipfile.ZipFile(q/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['legacy-saves.zip','run.py','prepare.py','old.gd','new.gd','fault.gd','results.json','compatibility.log','compatibility.json','proj3.log','read_projection.gd','report.py','canonical-before.log','canonical-before.json','revised.py','latest/inputs.json']:
  z.write(q/name,name)
 for name in names:
  for ext in ['.log','.json']:z.write(q/(name+ext),name+ext)
 for x in ['final-build.json','package-provenance.json','gui_external.gd','final-commit.txt','final-aim.gd','canonical.gd','legacy-fact.json','freeze.py','final-pack-gui.png']:
  if (q/x).is_file():z.write(q/x,x)
print(proof['status'],len(proof['runs']),archive.stat().st_size)
