import argparse, hashlib, json, os, pathlib, subprocess, sys, zipfile, io
root=pathlib.Path(__file__).resolve().parents[3]
q=pathlib.Path(__file__).resolve().parent
exe='D:/Program/Godot/Standard/Godot_v4.7.2-stable_win64_console.exe'
p=argparse.ArgumentParser()
p.add_argument('label')
p.add_argument('tree')
p.add_argument('script')
p.add_argument('--profile',default='test')
p.add_argument('--import',action='store_true',dest='imp')
p.add_argument('--arg',action='append',default=[])
p.add_argument('--display',action='store_true')
p.add_argument('--pack',default='')
p.add_argument('--png',default='')
a=p.parse_args()
tree=(root/a.tree).resolve(); profile=(q/'profiles'/a.profile)
profile.mkdir(parents=True,exist_ok=True)
env=dict(os.environ,APPDATA=str(profile),LOCALAPPDATA=str(profile))
if a.png:env['P3_QA_CAPTURE']=str((q/a.png).resolve())
command=[exe]+([] if a.display else ['--headless'])
if a.pack:command+=['--main-pack',str((root/a.pack).resolve())]
else:command+=['--path',str(tree)]
command+=['--log-file',str(q/(a.label+'-engine.log'))]
if a.imp: command+=['--import']
else:command+=['--script', a.script if a.script.startswith('res://') else str((q/a.script).resolve())]
if a.arg:command+=['--']+a.arg
work=q
if a.pack:
 work=q/'empty-cwd'
 work.mkdir(exist_ok=True)
 assert not any(work.iterdir())
r=subprocess.run(command,cwd=work,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=150)
raw=r.stdout;(q/(a.label+'.log')).write_bytes(raw)
bad=any(w in raw for w in (b'SCRIPT ERROR:',b'ERROR:',b'\nFAIL'))
record={'command':command,'exit':r.returncode,'error_output':bad,'stdout_sha256':hashlib.sha256(raw).hexdigest(),'user_profile':str(profile),'cwd':str(work)}
if a.pack:
 assert not any(work.iterdir())
 record['pack_sha256']=hashlib.sha256((root/a.pack).read_bytes()).hexdigest()
(q/(a.label+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n','utf-8')
print(a.label,r.returncode,bad,raw.decode('utf8','replace')[-900:])
sys.exit(1 if bad or r.returncode else 0)
