from pathlib import Path
import os,sys,json,hashlib,subprocess
q=Path(__file__).resolve().parent
root=q.parents[2]
ref=subprocess.check_output(['git','rev-parse',sys.argv[1]],cwd=root,text=True).strip()
for mpath in (root/'out/p3/build').rglob('manifest.json'):
 if mpath.parent.parent!=(root/'out/p3/build'):continue
 m=json.loads(mpath.read_bytes())
 if m.get('git_commit')!=ref or not all((mpath.parent/name).exists() for name in ['client.pck','server.pck','base.zip']):continue
 hashes={}
 for name,meta in m['artifacts'].items():
  f=mpath.parent/name
  actual=hashlib.sha256(f.read_bytes()).hexdigest()
  assert actual==meta['sha256'] and meta['size']==f.stat().st_size
  hashes[name]=actual
 (q/'package-provenance.json').write_text(json.dumps(dict(git_commit=ref,manifest=mpath.relative_to(root).as_posix(),manifest_sha256=hashlib.sha256(mpath.read_bytes()).hexdigest(),artifacts=hashes,engine='4.7.2.stable.official.ed1daf0bf'),indent=2)+'\n','utf8')
 (q/'final-commit.txt').write_text(ref+'\n','utf8')
 print(mpath.parent.relative_to(root).as_posix());break
else:sys.exit(1)
