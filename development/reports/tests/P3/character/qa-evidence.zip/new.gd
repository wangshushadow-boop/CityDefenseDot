extends SceneTree
const Boot=preload("res://bootstrap/composition_root.gd")
const Config=preload("res://bootstrap/boot_config.gd")
const Store=preload("res://infrastructure/persistence/save_service.gd")
const C=preload("res://contracts/canonical.gd")
var b
var st
var checks:=0
var failures:=0
func check(ok: bool,msg: String) -> bool:
	checks+=1
	if not ok:
		failures+=1
		printerr("FAIL ",msg)
	return ok
func _initialize() -> void:
	call_deferred("go")
func go() -> void:
	b=Boot.new(root)
	st=Store.new()
	var config:=Config.resolve([],DisplayServer.get_name(),{})
	if check(config.ok and b.boot(config.value).ok,"normal boot"):
		suite()
	b.shutdown()
	print("LEGACY_NEW checks=%d failures=%d"%[checks,failures])
	quit(0 if failures==0 and checks>=37 else 1)
func suite() -> void:
	for slot in ["oldempty","oldgoods"]:
		var old=st.recover(slot).value.snapshot
		check(not old.campaign.has("characters"),slot+" legacy campaign")
		var goods=slot=="oldgoods"
		var opened=b.load_world(slot)
		if not check(opened.ok,slot+" load actual old bytes "+str(opened)):return
		var first=b.character_view()
		if not check(first.ok,"old world character read "+str(first)):return
		var m=first.value
		check(m.world_id==old.world_id and m.hero==null and not m.ended, "no hero migrated, same id")
		check(old.content_hash==b.report().content_hash,"same installed content fingerprint")
		check(not b.session().query("character",{}).ok,"no read with missing principal")
		check(not b.character_command("outcome",{"kind":"death"},m.revision,"untrusted").ok,"no privileged outcome through player API")
		var created=b.character_command("create",{"name":"陵川","occupation":"caravan"},m.revision,"create-legacy")
		if not check(created.ok,"create after cold load "+str(created)):return
		var duplicate=b.character_command("create",{"name":"陵川","occupation":"caravan"},m.revision,"create-legacy")
		check(duplicate.ok and duplicate.value==created.value,"original create receipt")
		check(not b.character_command("create",{"name":"南庭"},m.revision,"create-legacy").ok,"collision different payload")
		var born=b.character_view().value
		var snap=st.recover(slot).value.snapshot
		check(snap.content_hash==old.content_hash and snap.content_packages==old.content_packages,"frozen content")
		check(snap.world_id==old.world_id and snap.game_minute==old.game_minute,"creation preserves world identity and clock")
		check(snap.campaign.characters.schema_version==1 and born.hero.id==born.player_id and born.family.size()==2,"single persistent player")
		if goods:
			check(snap.campaign.inventory.state.owners["p2-ancestral-talisman"]=="oldbag","original item survived genesis")
		var owners=snap.campaign.inventory.state.owners.duplicate(true)
		var old_player=born.player_id
		var heir=born.heirs[0].id
		var request=b.character_command("retire",{"heir_id":heir},born.revision,"retire-old")
		if not check(request.ok,"retire with real inventory "+str(request)):return
		var final=b.character_view().value
		check(final.player_id==heir and final.hero.id!=old_player,"legitimate transfer")
		var now=st.recover(slot).value.snapshot.campaign
		check(now.inventory.state.owners.size()==owners.size(),"all instance counts conserved")
		for id in born.gear.items:
			var owned:bool=born.gear.items[id].ownership=="family"
			check(final.gear.items.has(id)==owned,"personal/family ownership: "+id)
		if goods:check(now.inventory.state.owners["p2-ancestral-talisman"]=="oldbag","unrelated item untouched at inheritance")
		var saved_hero=final.hero.duplicate(true)
		check(b.session().close_session().ok and not b.character_view().ok,"closed principal invalid")
		var reload=b.load_world(slot)
		if not check(reload.ok,"cold reload post inheritance "+str(reload)):return
		var reread=b.character_view().value
		check(reread.hero.id==heir and reread.hero==saved_hero,"same persisted successor")
		check(b.session().close_session().ok,"close for next case")
		if goods:
			var bad=st.recover(slot).value.snapshot.duplicate(true)
			bad.campaign.characters.schema_version=99
			check(st.save_game("future",bad).ok,"future fixture saved through actual save service")
			check(not b.load_world("future").ok and b.session().query().value.state=="Frontend","future version refuses and stays frontend")
