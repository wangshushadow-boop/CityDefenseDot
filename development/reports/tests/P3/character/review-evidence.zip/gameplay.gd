extends SceneTree
const Hero = preload("res://campaign/character/hero_domain.gd")
const Gear = preload("res://campaign/character/gear.gd")
const Camp = preload("res://campaign/runtime.gd")
const ID := "hero/a4eb716d-8d36-4a95-9400-a0dee3b976cf"
var checks := 0
var failures := 0
func expect(value: bool, label: String) -> void:
	checks+=1
	print(("PASS " if value else "FAIL ")+label)
	if not value:failures+=1
func advance(h: Dictionary, skill: String, target: int) -> Dictionary:
	var n := 0
	while h.skills[skill].level<target and n<200:
		n+=1
		h=Hero.apply(h,"outcome",{"kind":"skill","source":skill+str(n),"skill":skill,"amount":10},0).value
	return h
func _initialize() -> void:
	var doctor:Dictionary=advance(Hero.create(ID,{"occupation":"healer"},0).value,"medicine",6)
	var medic:Dictionary=Hero.apply(doctor,"perk",{"perk":"medicine_hand"},0).value
	var wound:={"kind":"wound","source":"casualty/100","severity":70}
	var a:Dictionary=Hero.apply(Hero.apply(doctor,"outcome",wound,0).value,"rest",{},1).value
	var b:Dictionary=Hero.apply(Hero.apply(medic,"outcome",wound,0).value,"rest",{},1).value
	print("medicine=",medic.skills.medicine.level," self effect=",Hero.view(medic).effects.self.medicine," wounds plain/perk=",a.wounds,"/",b.wounds)
	expect(b.wounds<a.wounds,"personal medicine bonus changes the available recovery mechanic when crossing one threshold")
	var rider:Dictionary=advance(Hero.create(ID,{"occupation":"caravan"},0).value,"riding",6)
	var proficient:Dictionary=Hero.apply(rider,"perk",{"perk":"riding_hand"},0).value
	var inv=Gear.apply(null,proficient,"create",{},"creation").value
	var lance_id: String=""
	var gear:Dictionary=Gear.view(inv,proficient).value
	for id in gear.items:
		if id.ends_with("/lance"): lance_id=id
	var swap:=Gear.apply(inv,proficient,"equip",{"profile":"combat","slot":"main_hand","item_id":lance_id},"swap")
	print("riding=",proficient.skills.riding.level," self effect=",Hero.view(proficient).effects.self.riding," mounted=",gear.profiles.combat.mount," swap=",swap.get("error",{}))
	expect(swap.ok,"personal riding bonus applies to eight-point equipment requirement on already equipped mount")
	var camp:=Camp.new()
	camp.create_world("0000000000000008",{},{"content_hash":"a".repeat(64),"packages":[]})
	var write:=func(_w,_r):return {"ok":true,"value":null}
	camp.character_command("create",{},"char",write)
	var id: String=camp.character_view().value.player_id
	camp.character_command("outcome",{"kind":"wound","hero_id":id,"source":"world/battle","severity":70},"wound",write)
	var traveler:=Camp.new()
	traveler.restore(camp.save_snapshot().value)
	var healed:Dictionary=camp.character_command("rest",{},"rest",write)
	var advanced:Dictionary=traveler.step_until(1440,100)
	var resting:int=camp.character_view().value.hero.wounds
	var traveling:int=traveler.character_view().value.hero.wounds
	print("resting=",resting," ordinary=",traveling)
	expect(healed.ok and advanced.ok and resting<traveling,"choosing rest grants rest bonus relative to generic clock progression")
	print("GAMEPLAY_REVIEW checks=%d failures=%d"%[checks,failures])
	quit(0 if failures==0 else 1)
