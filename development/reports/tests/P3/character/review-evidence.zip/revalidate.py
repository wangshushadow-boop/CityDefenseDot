from pathlib import Path
import subprocess,os,hashlib,json,re,sys
root=Path.cwd(); d=root/'out/p3/review'; work=Path(sys.argv[1]).resolve(); dst=d/sys.argv[2];dst.mkdir(exist_ok=True)
exe='D:/Program/Godot/Standard/Godot_v4.7.2-stable_win64_console.exe'
probes=[(n,str(d/s),m) for n,s,m in [('provenance','reservations.gd','REVIEW'),('effects','gameplay.gd','GAMEPLAY_REVIEW')]]
for name in ['hero','gear','gear_inventory','character_flow','campaign_character','session_character']:
 s=work/'game/tests/p3'/name/'run.gd'
 if s.is_file():probes.append((name,str(s),''))
runs=[]
for name,src,marker in probes:
 home=dst/(name+'-home');home.mkdir(exist_ok=True)
 args=[exe,'--headless','--path',str(work/'game'),'--script',src,'--log-file',str(dst/(name+'-engine.log'))]
 out=subprocess.run(args,env=dict(os.environ,APPDATA=str(home),LOCALAPPDATA=str(home)),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=105)
 log=out.stdout.decode('utf8','replace');last=[x for x in log.splitlines() if x.strip()][-1];(dst/(name+'.log')).write_bytes(out.stdout)
 ok=out.returncode==0 and not any(x in log for x in ('SCRIPT ERROR:','ERROR:','FAIL ')) and marker in log
 runs.append({'name':name,'script':src,'exit':out.returncode,'result':last,'ok':ok});print(name,out.returncode,ok,last,flush=True)
files=['campaign/runtime.gd','application/game_session.gd','bootstrap/composition_root.gd','bootstrap/desktop.gd','campaign/character/ports/characters.gd','campaign/clan/ports/character_household.gd','campaign/character/hero_domain.gd','campaign/character/hero_rules.json','campaign/character/gear.gd','shared/inventory/inventory.gd','presentation/ui/ports/character_panel.gd']
hashes={name:hashlib.sha256((work/'game'/name).read_bytes().replace(b'\r\n',b'\n')).hexdigest() for name in files}
(dst/'results.json').write_text(json.dumps({'work':str(work),'runs':runs,'sha256_lf':hashes},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
raise SystemExit(0 if all(r['ok'] for r in runs) else 1)