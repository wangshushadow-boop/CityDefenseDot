# P3 人物候选独立审查 · 第一轮

结论为 CHANGES_REQUIRED。测试由 Godot 4.7.2 Standard 运行在集成副本，候选库存与装备 9a2711d、6cdc006，人物 8945db4，CAMP、APP、BOOT 与 CHR/CLAN 端口为集成前工作区。review.gd 冷创建真实 Campaign，从原有库存和人物用例出发；gameplay.gd 用合法技能经验和天赋命令构造个人医术、骑术对照。

1. 通用库存交换及日结计划可以提交人物物品流出人物持有者的记录。写入成功后对应快照无法再次恢复。正常推进与人物主动休养的日结均复现。CAMP/runtime.gd 的 exchange、_day_plan，CHR-02。
2. 仅移除人物仓库时，存档还留有人物持有者，但兼容旧档分支仍返回成功，随后新建人物因同名位置冲突。CAMP/runtime.gd 的 restore，CHR-02/03。
3. 自身医术、骑术在人物面板正确获得 +2，实际恢复、骑矛装备要求只读取基础值。6 级医术持有人学习该天赋前后，实际 70 伤在休息一日后均为 59；6 级骑术且已有坐骑者学习自身天赋后仍拒绝 8 技能装备。Hero.apply(rest)、Gear._reason，CHR-01/02/03。
4. 同一健康余量、日历和医术的两条轨迹，主动休养一日与普通日结均将 70 伤降到 60；现有选择没有相应休养加成差异。Hero.apply(rest)、Characters.recover 及 CAMP 日结，CHR-03。
5. 不相交的来源区间指向同一健康 HeroId 时，campaign.check_character_sources 接受了两次，同一人物可以占用两个兵员位置。应在 campaign 的人物来源核验阶段去重，普通兵保留原计数行为。CHR-03。

实际日志 initial.log、effects-recount.log、reservations.log。首次探索 effects.log 的医术点未跨门槛且复验采用带软限衰减的 1 单位练习，已用官方合法经验量和 6 级重做。完整发布包和全部修复候选等待复核。