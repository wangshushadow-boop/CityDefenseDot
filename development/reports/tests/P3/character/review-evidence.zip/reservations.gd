extends SceneTree
const Camp = preload("res://campaign/runtime.gd")
const Characters = preload("res://campaign/character/ports/characters.gd")
const V = preload("res://contracts/values.gd")
var checks := 0
var problems := 0
func test(value: bool, name: String) -> void:
	checks += 1
	print(("PASS " if value else "FAIL ")+name)
	if not value: problems+=1
func _initialize() -> void:
	var camp := Camp.new()
	var original := camp.create_world("0000000000000007",{"locations":{"quartermaster":{"kind":"inventory","capacity":60}}},{"content_hash":"a".repeat(64),"packages":[{"id":"base","version":"1"}]})
	test(original.ok, "real campaign and ordinary inventory")
	var durable := func(_s,_r):return {"ok":true,"value":null}
	test(camp.character_command("create",{},"review/create",durable).ok,"real character setup")
	var saved := camp.save_snapshot().value as Dictionary
	var p := camp.character_view().value as Dictionary
	var sources=[{"hero_id":p.player_id,"count":1,"source_slot_range":[0,1]},{"hero_id":p.player_id,"count":1,"source_slot_range":[1,2]}]
	test(not camp.check_character_sources(sources).ok,"one hero cannot be deployed twice through separate slots")
	var no_char := saved.duplicate(true)
	no_char.erase("characters")
	var restored := Camp.new()
	var restored_orphans := restored.restore(no_char)
	var orphan_recreate := restored.character_command("create",{},"review/second",durable) if restored_orphans.ok else {}
	print("orphan accepted=",restored_orphans," recreate=",orphan_recreate)
	test(not restored_orphans.ok,"cold restore with existing hero gear and missing CHR repository is rejected")
	var future := saved.duplicate(true)
	future.characters.heroes[p.player_id].recovery_day=99
	var future_world:=Camp.new()
	var future_load:=future_world.restore(future)
	var future_rest := future_world.character_command("rest",{},"review/rest",durable) if future_load.ok else {}
	print("future accepted=",future_load," rest=",future_rest)
	test(not future_load.ok,"future daily cursor rejected before leaving world unusable")
	var item: String=p.gear.profiles.combat.main_hand
	var before: String=saved.inventory.state.owners[item]
	var outgoing := [{"src":before,"dst":"quartermaster","resource":{"kind":"instance","id":item},"amount":1,"reason":"requisition","source_ref":"review/1"}]
	var moved := camp.exchange("review/transfer",outgoing,-1,durable)
	var final := camp.save_snapshot().value as Dictionary
	var final_cold := Camp.new().restore(final)
	print("ordinary exchange ok=",moved.ok," restore ok=",final_cold.ok," cold_error=",final_cold.get("error",{}))
	test(not moved.ok or final_cold.ok,"successful ordinary campaign transaction still loads a cold world")
	var day_world:=Camp.new()
	day_world.restore(saved)
	day_world.register_phase("production","carry",func(_c):return {"ok":true,"value":outgoing})
	var stepped:=day_world.step_until(1440,100)
	var next_cold:=Camp.new().restore(day_world.save_snapshot().value)
	print("normal daily ok=",stepped.ok," restore ok=",next_cold.ok)
	test(not stepped.ok or next_cold.ok,"successful normal daily plan still loads a cold world")
	var other_world:=Camp.new()
	other_world.restore(saved)
	other_world.register_phase("production","carry",func(_c):return {"ok":true,"value":outgoing})
	var rest:=other_world.character_command("rest",{},"review/rest",durable)
	var rest_cold:=Camp.new().restore(other_world.save_snapshot().value)
	print("rest daily ok=",rest.ok," restore ok=",rest_cold.ok)
	test(not rest.ok or rest_cold.ok,"successful player rest still loads a cold world")
	print("REVIEW checks=%d failures=%d"%[checks,problems])
	quit(0 if problems==0 else 1)
