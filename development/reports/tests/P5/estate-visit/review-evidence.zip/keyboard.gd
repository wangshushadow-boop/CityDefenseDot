extends "res://tests/p5/estate_desktop/run.gd"

func keyboard_press(caption:String)->bool:
	for i in 45:
		var focus:=root.gui_get_focus_owner()
		if focus is Button and focus.is_visible_in_tree() and focus.text==caption and not focus.disabled:
			if not check(root.get_visible_rect().has_point(focus.get_global_rect().get_center()),"keyboard focus visible: "+caption):return false
			key(KEY_ENTER)
			await process_frame
			return true
		key(KEY_TAB)
		await process_frame
	check(false,"could not tab to "+caption)
	return false

func scenario()->void:
	main._desktop._slot.text="rkey-"+Crypto.new().generate_random_bytes(8).hex_encode()
	for caption in ["新建沙盒","人物","确立身世","领地治理","接管柳溪庄"]:
		if not await press(caption):return
	var heir:Dictionary=model().heirs[0]
	if not await press("任命"+str(heir.name)):return
	for caption in ["拜访庄署","会见"+str(heir.name),"问庄中近况","谈核对庄簿","接下核账委托","委托簿","休养一日","向总督回报"]:
		if not await keyboard_press(caption):return
	var ledger:Dictionary=model().visit.ledger
	var reply:="斟酌"
	reply="%+.1f 点"%((ledger.prosperity_after-ledger.prosperity_before)/10.0)
	if not await keyboard_press(reply):return
	for caption in ["委托簿","领取管理经验","在场名册","返回治理"]:
		if not await keyboard_press(caption):return
	check(model().visit.rewarded and button("拜访庄署")!=null,"tab-only completion and return")
	print("TAB ONLY commissioned and returned to estate")
