extends SceneTree

const Camp = preload("res://campaign/runtime.gd")
const C = preload("res://contracts/canonical.gd")
const R = preload("res://contracts/result.gd")
var checks := 0
var failures := 0

func check(condition: bool, label: String) -> bool:
	checks += 1
	print("PASS " if condition else "FAIL ", label)
	if not condition: failures += 1
	return condition

func persist(_world: Dictionary, _ack: Dictionary) -> Dictionary:
	return R.ok()

func rejected(campaign: RefCounted, original: Dictionary, tampered: Dictionary, label: String, rehash: bool = true) -> void:
	if rehash:
		tampered.estate_commission.ledger_hash = C.hash_value(tampered.estate_commission.ledger).value
	var result: Dictionary = campaign.restore(tampered)
	var unchanged: bool = campaign.save_snapshot().value == original
	check(not result.ok and unchanged, label + "  " + str(result.get("error")))

func exercise() -> void:
	var bytes := FileAccess.get_file_as_bytes(OS.get_cmdline_user_args()[0])
	var input := C.decode(bytes)
	if not check(input.ok, "cold read P4 canonical file"): return
	var old: Dictionary = input.value
	var campaign := Camp.new()
	if not check(campaign.restore(old).ok, "P5 restores real pre-commission world"): return
	var model: Dictionary = campaign.character_view().value
	var target := {"hero_id":old.governance.governor_id, "settlement_id":old.governance.settlement_id}
	check(model.visit.status == "none" and model.visit.can_accept and model.visit.speaker.id == target.hero_id, "P4 actual incumbent can offer")
	check(campaign.save_snapshot().value == old, "unchanged P4 snapshot after read")
	if not check(campaign.character_command("visit_accept", target, "d4", persist).ok, "D4 accept on D3 estate"): return
	if not check(campaign.step_until(6 * 1440, 256).ok, "D5 lock, D6 rollover"): return
	var original: Dictionary = campaign.save_snapshot().value
	var retained: Dictionary = original.estate_commission.ledger
	check(retained.day == 5 and original.governance.last_report.day == 6, "retained ledger is past initial settlement day")
	var candidate: Dictionary = original.duplicate(true)
	check(C.hash_value(retained).value == original.estate_commission.ledger_hash, "canonical receipt written")
	candidate.estate_commission.ledger.prosperity_bonus -= 1
	candidate.estate_commission.ledger.prosperity_before += 1
	rejected(campaign,original,candidate,"stale digest despite valid arithmetic and same closing",false)
	candidate = original.duplicate(true)
	candidate.estate_commission.ledger.prosperity_after += 1
	candidate.estate_commission.ledger.prosperity_before += 1
	rejected(campaign,original,candidate,"recomputed digest cannot detach adjacent prosperity")
	candidate = original.duplicate(true)
	candidate.estate_commission.ledger.loyalty_after += 1
	candidate.estate_commission.ledger.loyalty_before += 1
	rejected(campaign,original,candidate,"recomputed digest cannot detach adjacent loyalty")
	candidate = original.duplicate(true)
	candidate.estate_commission.accepted_day = 2
	candidate.estate_commission.deadline_day = 5
	candidate.estate_commission.ledger.day = 3
	rejected(campaign,original,candidate,"recomputed digest cannot move acceptance before opening")
	if not check(campaign.step_until(7 * 1440, 256).ok, "D7 displaces even adjacent SET record"): return
	original = campaign.save_snapshot().value
	candidate = original.duplicate(true)
	candidate.estate_commission.ledger.prosperity_bonus = 800
	candidate.estate_commission.ledger.prosperity_after = 1000
	rejected(campaign,original,candidate,"recomputed digest cannot exceed actual issuer skill after two rollovers")
	candidate = original.duplicate(true)
	candidate.estate_commission.ledger.loyalty_after += 1
	rejected(campaign,original,candidate,"recomputed digest cannot bypass SET arithmetic after two rollovers")
	check(campaign.restore(original).ok and campaign.character_view().value.visit.can_report, "valid unchanged old ledger can still be reported on final day")

func _initialize() -> void:
	exercise()
	print("HISTORY checks=",checks," failures=",failures)
	quit(1 if failures else 0)
