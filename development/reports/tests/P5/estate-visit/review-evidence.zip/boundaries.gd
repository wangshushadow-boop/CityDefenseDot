extends SceneTree
const Camp = preload("res://campaign/runtime.gd")
const R = preload("res://contracts/result.gd")
const F = preload("res://tests/p1/application/fixture.gd")
var checks := 0
var failures := 0

func check(condition:bool, name:String) -> bool:
	checks += 1
	if not condition:
		failures += 1
		printerr("FAIL ",name)
	return condition

func accept(_world:Dictionary, _ack:Dictionary)->Dictionary:
	return R.ok()

func run() -> void:
	var live:=Camp.new()
	var options:=F.options("review")
	options.start_def["game_minute"]=3*1440
	if not check(live.create_world(options.seed, options.start_def, F.CONTENT).ok, "real world"): return
	if not check(live.character_command("create",{"culture":"river"},"house",accept).ok,"river family"): return
	if not check(live.character_command("governor_open",{},"estate",accept).ok,"open on D3"): return
	var person:Dictionary=live.character_view().value
	var target:={"hero_id":person.heirs[0].id,"settlement_id":person.governance.settlement_id}
	if not check(live.character_command("governor_assign",target,"appoint",accept).ok and live.character_command("visit_accept",target,"accept",accept).ok,"appoint and accept on D3"): return
	check(live.step_until(4*1440,256).ok,"D4 actual ledger")
	var first:Dictionary=live.character_view().value.visit.ledger
	check(live.step_until(5*1440,256).ok,"D5 overwrites SET daily report")
	var now:Dictionary=live.save_snapshot().value
	var cold:=Camp.new()
	if not check(cold.restore(now).ok,"valid D5 cold load"):return
	check(now.governance.last_report.day==5 and now.estate_commission.ledger.day==4 and now.governance.opened_day==3,"established D3, current D5, authentic commission D4")
	var fake:Dictionary=now.duplicate(true)
	fake.estate_commission.ledger.prosperity_bonus=800
	fake.estate_commission.ledger.prosperity_after=1000
	var loaded:Dictionary=cold.restore(fake)
	print("history wrong bonus loaded=",loaded.ok," logged before=",first.prosperity_before," bonus actual=",first.prosperity_bonus," latest open=",now.governance.last_report.prosperity_before)
	check(not loaded.ok,"reject bonus 800 for governor skill 2")
	fake=now.duplicate(true)
	fake.estate_commission.ledger.prosperity_before+=1
	fake.estate_commission.ledger.prosperity_after+=1
	loaded=cold.restore(fake)
	print("adjacent-day break loaded=",loaded.ok)
	check(not loaded.ok,"D4 closing must equal D5 opening")
	fake=now.duplicate(true)
	fake.estate_commission.accepted_day=2
	fake.estate_commission.deadline_day=5
	fake.estate_commission.ledger.day=3
	loaded=cold.restore(fake)
	print("pre-estate commission loaded=",loaded.ok)
	check(not loaded.ok,"cannot accept before estate exists")
	# A genuine world that advances and places the member back into office cannot salvage the old task.
	check(cold.restore(now).ok,"reset to genuine history")
	check(cold.character_command("governor_dismiss",{"settlement_id":target.settlement_id},"end-tenure",accept).ok,"dismiss original")
	check(cold.character_command("governor_assign",target,"restore-office",accept).ok,"reappoint same member")
	var old_request:Dictionary=target.duplicate()
	old_request["answer"]=first.prosperity_after-first.prosperity_before
	check(not cold.character_command("visit_report",old_request,"report-invalid-term",accept).ok,"same hero new term cannot sign old task")
	check(not cold.character_command("visit_accept",target,"same-day-reoffer",accept).ok,"failed task cannot immediately be redone")
	check(cold.character_view().value.visit.status=="failed","journal keeps loss of term")
	check(cold.step_until(6*1440,256).ok and cold.character_command("visit_accept",target,"new-term",accept).ok,"later new commission")
	check(cold.step_until(7*1440,256).ok,"new ledger")
	var ledger:Dictionary=cold.character_view().value.visit.ledger
	old_request.answer=ledger.prosperity_after-ledger.prosperity_before
	check(cold.character_command("visit_report",old_request,"new-report",accept).ok,"can sign new work")
	check(cold.character_command("governor_dismiss",{"settlement_id":target.settlement_id},"second-dismiss",accept).ok,"signed work survives issuer exit")
	var paid:Dictionary=cold.character_command("visit_claim",{},"paid",accept)
	check(paid.ok and cold.character_view().value.visit.rewarded,"receipt original actor can collect after departure")
	check(not cold.character_command("visit_claim",{},"double",accept).ok,"no duplicate XP")

func _initialize()->void:
	run()
	print("REVIEW_BOUNDARIES checks=",checks," failures=",failures)
	quit(1 if failures else 0)
