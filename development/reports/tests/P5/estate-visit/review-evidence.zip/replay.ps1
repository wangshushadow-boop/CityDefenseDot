param(
    [Parameter(Mandatory)][string]$Repository,
    [string]$Engine = 'D:\Program\Godot\Standard\Godot_v4.7.2-stable_win64_console.exe',
    [string]$Scratch = (Join-Path $PSScriptRoot 'replay-output')
)
$ErrorActionPreference = 'Stop'
$base = '9b975cc1b1809b620415aa64101e74df8b351252'
$initial = 'f8c9bdb3f693a8bea840d8a30330c2f1d8f27aae'
$final = '4cfca392e3ff9cfaaf0cc239d268da2a4e464e99'
New-Item -Path $Scratch -ItemType Directory -Force | Out-Null
$Scratch = (Resolve-Path -LiteralPath $Scratch).Path
$env:APPDATA = $Scratch
$env:LOCALAPPDATA = $Scratch
function Project([string]$rev) {
    return Join-Path (Join-Path $Scratch $rev) 'game'
}
foreach ($rev in @($base, $initial, $final)) {
    $packed = Join-Path $Scratch "$rev.zip"
    if (Test-Path -LiteralPath (Project $rev)) { throw "请选择空的 Scratch 目录，以便从 Git 冷归档 $rev" }
    & git -C $Repository archive --format=zip -o $packed $rev game
    if ($LASTEXITCODE -ne 0) { throw "git archive failed: $rev" }
    Expand-Archive -LiteralPath $packed -DestinationPath (Join-Path $Scratch $rev)
}
function Launch([string]$label, [string]$rev, [string[]]$options, [int]$expected = 0) {
    & $Engine --path (Project $rev) --log-file (Join-Path $Scratch "$label.log") @options
    if ($LASTEXITCODE -ne $expected) { throw "$label exit $LASTEXITCODE expected $expected" }
}
$old = Join-Path $Scratch 'legacy-p4.json'
Launch 'old-baseline' $base @('--headless','--script',(Join-Path $PSScriptRoot 'old_estate.gd'),'--',$old)
Launch 'boundaries-initial' $initial @('--headless','--script',(Join-Path $PSScriptRoot 'boundaries.gd')) 1
if (-not (Select-String -Quiet -SimpleMatch 'REVIEW_BOUNDARIES checks=23 failures=3' -LiteralPath (Join-Path $Scratch 'boundaries-initial.log'))) { throw '首轮应复现原三项失败' }
Launch 'editor-final' $final @('--headless','--editor','--import')
Launch 'boundaries-final' $final @('--headless','--script',(Join-Path $PSScriptRoot 'boundaries.gd'))
Launch 'history-final' $final @('--headless','--script',(Join-Path $PSScriptRoot 'history.gd'),'--',$old)
foreach ($suite in @('estate_commission','visit_people','estate_campaign','visit_session')) {
    Launch "$suite-final" $final @('--headless','--script',"res://tests/p5/$suite/run.gd")
}
Launch 'keyboard-final' $final @('--windowed','--resolution','960x600','--max-fps','60','--script',(Join-Path $PSScriptRoot 'keyboard.gd'),'--','--profile=client')
Write-Output "已复现原失败并通过终版验证。日志在 $Scratch"
