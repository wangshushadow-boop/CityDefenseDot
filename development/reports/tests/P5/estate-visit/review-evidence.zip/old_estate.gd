extends SceneTree

const Camp = preload("res://campaign/runtime.gd")
const F = preload("res://tests/p1/application/fixture.gd")
const C = preload("res://contracts/canonical.gd")
const R = preload("res://contracts/result.gd")

func persist(_world: Dictionary, _ack: Dictionary) -> Dictionary:
	return R.ok()

func emit_old_estate() -> bool:
	var campaign := Camp.new()
	var o := F.options("review-legacy")
	o.start_def["game_minute"] = 3 * 1440
	if not campaign.create_world(o.seed, o.start_def, F.CONTENT).ok: return false
	if not campaign.character_command("create", {"culture":"river"}, "house", persist).ok: return false
	if not campaign.character_command("governor_open", {}, "open", persist).ok: return false
	var model: Dictionary = campaign.character_view().value
	var target := {"hero_id":model.heirs[0].id, "settlement_id":model.governance.settlement_id}
	if not campaign.character_command("governor_assign", target, "appoint", persist).ok: return false
	if not campaign.step_until(4 * 1440, 256).ok: return false
	var snapshot: Dictionary = campaign.save_snapshot().value
	if snapshot.has("estate_commission") or snapshot.governance.last_report.day != 4: return false
	var data := C.encode(snapshot)
	var path := OS.get_cmdline_user_args()[0]
	var file := FileAccess.open(path, FileAccess.WRITE)
	if not data.ok or not file: return false
	file.store_buffer(data.value)
	file.close()
	print("P4 actual governor=", target.hero_id, " D4 estate, no commission, bytes=", data.value.size())
	return true

func _initialize() -> void:
	quit(0 if emit_old_estate() else 1)
