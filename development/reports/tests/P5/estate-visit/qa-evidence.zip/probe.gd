extends SceneTree
const Boot = preload("res://bootstrap/composition_root.gd")
const Config = preload("res://bootstrap/boot_config.gd")
const Store = preload("res://infrastructure/persistence/save_service.gd")
const App = preload("res://application/game_session.gd")
const Camp = preload("res://campaign/runtime.gd")
const Canon = preload("res://contracts/canonical.gd")
const R = preload("res://contracts/result.gd")
const SLOT := "oldgovernor"
const FOREIGN := "hero/00000000-0000-4000-8000-0000000000aa"
const FOREIGN_FIEF := "settlement/00000000-0000-4000-8000-0000000000aa"
const PARTY := "party/00000000-0000-4000-8000-0000000000aa"
var checks := 0
var failures := 0
var store := Store.new()
var app: RefCounted
var player := RefCounted.new()
var authority := RefCounted.new()
var world := ""
var session_id := ""
var founder := ""
var heir := ""
var fief := ""
var original := {}
var content := {}

func ck(ok: bool, label: String) -> bool:
	checks += 1
	if ok:
		print("PASS ", label)
	else:
		printerr("FAIL ", label)
		failures += 1
	return ok

func _initialize() -> void:
	run.call_deferred()

func snapshot() -> Dictionary:
	return store.recover(SLOT).value.snapshot

func view() -> Dictionary:
	return app.query("character", {"context":player}).value

func permit(token: Variant, op: String, req: Dictionary) -> Dictionary:
	if req.get("scope_id") != world or req.get("session_id") != session_id:
		return R.fail("Unauthorized","session")
	if is_same(token, player):
		return R.ok("player")
	if is_same(token, authority) and op == "character.outcome":
		return R.ok("character.authority")
	return R.fail("Unauthorized", "qa_identity")

func bind() -> void:
	player = RefCounted.new()
	session_id = app.query().value.session_id

func envelope(id: String, action: String, args: Dictionary, actor: String="player") -> Dictionary:
	return {"command_id":id,"actor_ref":actor,"scope_id":world,"expected_revision":view().revision,
		"issued_tick":null,"sequence":null,"payload":{"type":"character."+action,"args":args}}

func cmd(id: String, action: String, args: Dictionary={}) -> Dictionary:
	return app.dispatch(envelope(id, action, args), player)

func outcome(id: String, kind: String, hero: String, extra: Dictionary={}) -> Dictionary:
	var payload := {"source":id,"hero_id":hero,"kind":kind}
	payload.merge(extra)
	return app.dispatch(envelope(id,"outcome",payload,"character.authority"), authority)

func candidate(id: String) -> Dictionary:
	for row in view().governance.candidates:
		if row.id == id:
			return row
	return {}

func cold() -> bool:
	var expected := view()
	var retired_token := player
	var next: RefCounted = App.new(store,func(): return Camp.new(),Callable(),permit)
	if not ck(app.close_session().ok and next.load_session(SLOT,content).ok, "close and reload real store into fresh application"):
		return false
	app = next
	bind()
	return ck(view() == expected and not app.query("character",{"context":retired_token}).ok, "exact cold projection and fresh authority token")

func baseline() -> void:
	var path := OS.get_environment("P5_QA_ROOT").path_join(OS.get_environment("P5_QA_BASELINE"))
	var old: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(path))
	ck(original.world_id==old.world and original.content_hash==old.content_hash,"physical P4 world and content hash")
	ck(Canon.hash_value(original.campaign.characters).value==old.character_hash,"P4 character identity, equipment and skills unchanged on import")
	ck(Canon.hash_value(original.campaign.inventory).value==old.inventory_hash,"P4 physical inventory unchanged")
	ck(Canon.hash_value(original.campaign.governance).value==old.governance_hash,"P4 appointment, accounts and daily cursor unchanged")
	ck(Canon.hash_value(original.session.commands).value==old.receipt_hash and original.session.commands.size()==old.get("receipts",6),"all original command receipts retained")

func run() -> void:
	original = snapshot()
	content = {"content_hash":original.content_hash,"packages":original.content_packages}
	world = original.world_id
	var boot = Boot.new(root)
	var cfg := Config.resolve([],DisplayServer.get_name(),{})
	if ck(boot.boot(cfg.value).ok and boot.load_world(SLOT).ok,"production BOOT cold-loads real P4 incumbent"):
		var v: Dictionary=boot.character_view().value
		ck(v.governance.established and v.governance.governor_id==v.heirs[0].id and v.day==3,"incumbent, household and day preserved")
		ck(boot.character_command("create",{"name":"令秋","culture":"river"},0,"old-create").ok,"original physical receipt replays through BOOT")
	boot.shutdown()
	if failures==0:
		app=App.new(store,func(): return Camp.new(),Callable(),permit)
		if ck(app.load_session(SLOT,content).ok,"load same physical world into an independently authorized application"):
			bind()
			baseline()
			founder=view().player_id
			heir=view().governance.governor_id
			fief=view().governance.settlement_id
			if OS.get_environment("P5_QA_SCENARIO")=="seed":
				seed_old_collision()
			else:
				p5_path()
		app.close_session()
	print("P5_INDEPENDENT checks=%s failures=%s"%[checks,failures])
	quit(int(failures!=0))

func seed_old_collision() -> void:
	var source: String="quest/liuxi/%s/%d"%[founder,view().day]
	if not ck(outcome(source,"skill",founder,{"skill":"leadership","amount":7}).ok,"actual P4 accepted a legitimate event source matching the future P5 key"):return
	var disk:=snapshot()
	ck(not disk.campaign.has("estate_commission") and not disk.campaign.characters.has("estate_reward"),"P4 save has no P5 data")
	print("P4_COLLISION ",JSON.stringify({"world":world,"content_hash":disk.content_hash,"inventory_hash":Canon.hash_value(disk.campaign.inventory).value,"character_hash":Canon.hash_value(disk.campaign.characters).value,"governance_hash":Canon.hash_value(disk.campaign.governance).value,"receipts":disk.session.commands.size(),"receipt_hash":Canon.hash_value(disk.session.commands).value,"old_source":source}))

func p5_path() -> void:
	var v := view()
	if not ck(v.has("visit") and v.visit.status=="none" and v.visit.can_visit and v.visit.can_accept and v.visit.speaker.id==heir, "only current P4 governor available to visit"): return
	ck(v.visit.speaker.name==v.heirs[0].name and v.visit.speaker.appearance==original.campaign.characters.heroes[heir].appearance,"display name and appearance come from existing governor")
	ck(not original.campaign.has("estate_commission") and not v.visit.can_claim and v.visit.ledger.is_empty(),"no retroactive commission")
	if not ck(not app.dispatch(envelope("outsider","visit_accept",args()),authority).ok,"player-only permission required"):return
	var wrong := args()
	wrong.hero_id = founder
	ck(not cmd("wrong-npc","visit_accept",wrong).ok,"inactive issuer cannot be supplied by client")
	wrong = args()
	wrong.settlement_id = FOREIGN_FIEF
	ck(not cmd("wrong-fief","visit_accept",wrong).ok,"foreign settlement refused")
	wrong = args()
	wrong["rewarded"] = true
	ck(not cmd("wrong-fields","visit_accept",wrong).ok and snapshot()==original,"forged fields, identity and authority leave disk unchanged")
	var start := envelope("opening","visit_accept",args())
	var receipt: Dictionary = app.dispatch(start,player)
	if not ck(receipt.ok and view().visit.status=="active","accept real incumbent's job"): return
	var active: Dictionary=view().visit
	ck(active.issuer_id==heir and active.actor_id==founder and active.accepted_day==3 and active.deadline_day==6 and active.ledger.is_empty(),"accept freezes correct people and three-day window")
	ck(app.dispatch(start,player)==receipt,"same accept receipt replay")
	ck(not cmd("early","visit_report",answers(0)).ok and not cmd("early-claim","visit_claim").ok,"no reporting or claiming before the next day")
	ck(not cmd("twice","visit_accept",args()).ok and not view().visit.can_accept,"single active commission")
	if not cold(): return
	match OS.get_environment("P5_QA_SCENARIO"):
		"success": success_path()
		"expiry": expiry_path()
		"succession","unclaimed": heir_path()
		"disappear": lost_issuer()
		"away": absence()
		_: ck(false,"unknown QA scenario")

func args() -> Dictionary:
	return {"settlement_id":fief,"hero_id":heir}

func answers(choice: int) -> Dictionary:
	var supplied := args()
	supplied["answer"] = choice
	return supplied

func day(id: String) -> bool:
	return ck(cmd(id,"rest").ok, "advance real campaign "+id)

func ready() -> bool:
	if not day("first-day"):return false
	var v := view()
	if not ck(v.visit.status=="ready" and v.visit.ledger==v.governance.last_report and v.visit.ledger.day==4,"quest captured actual D+1 governance journal"):return false
	var correct: int = v.governance.last_report.prosperity_after - v.governance.last_report.prosperity_before
	return ck(v.visit.can_report and v.visit.answers.size()==3 and v.visit.answers.has(correct),"three choices include actual gain")

func finish() -> bool:
	var before := view()
	var gain: int = before.visit.ledger.prosperity_after-before.visit.ledger.prosperity_before
	var wrong: Array = before.visit.answers.filter(func(n):return n!=gain)
	var denied := cmd("wrong","visit_report",answers(wrong[0]))
	if not denied.ok:
		ck(denied.error.field!="canonical","distinct submitted wrong answer reached game rules")
	ck(view().visit.status=="ready" and not view().visit.can_claim and not view().visit.rewarded,"wrong answer cannot sign off or collect AMT")
	ck(snapshot().campaign.characters.heroes[founder].skills==original.campaign.characters.heroes[founder].skills,"wrong report grants no personal skill gain")
	var envelope1 := envelope("correct","visit_report",answers(gain))
	var ok: Dictionary = app.dispatch(envelope1,player)
	if not ok.ok: print("REPORT_ERROR ",ok)
	if not ck(ok.ok and view().visit.status=="completed" and view().visit.can_claim and not view().visit.rewarded,"report signs off without paying automatically"): return false
	ck(app.dispatch(envelope1,player)==ok,"signed report receipt replay")
	return true

func success_path() -> void:
	if not ready():return
	var ledger: Dictionary = view().visit.ledger.duplicate(true)
	if not day("another-day") or not day("last-day"):return
	ck(view().day==6 and view().visit.can_report and view().governance.last_report.day==6 and view().visit.ledger==ledger,"accepted original ledger survives D+3 final reporting day")
	if not finish():return
	if not ck(cmd("dismiss","governor_dismiss",{"settlement_id":fief}).ok,"dismiss original issuer after signing"):return
	ck(view().visit.speaker==null and view().visit.can_claim,"signed commission independently claimable from journal after vacancy")
	if not cold():return
	var before := snapshot()
	var event := envelope("paid","visit_claim",{})
	store.fault_point="before_marker"
	var failed_write: Dictionary=app.dispatch(event,player)
	ck(not failed_write.ok and failed_write.error.code=="Unavailable" and view().visit.can_claim,"pre-marker disk failure reached store and left in-memory reward available")
	ck(snapshot()==before,"failed write leaves physical XP, quest, receipts and appointment unchanged")
	store.fault_point=""
	store.fault_point="after_marker"
	var ambiguous: Dictionary=app.dispatch(event,player)
	store.fault_point=""
	print("CLAIM_RECEIPT ",ambiguous)
	ck(not ambiguous.ok and ambiguous.error.code=="Unavailable" and view().visit.rewarded,"lost acknowledgement reconciles durable reward")
	var receipt: Dictionary=app.dispatch(event,player)
	print("CLAIM_RETRY ",receipt)
	if not ck(receipt.ok and not view().visit.can_claim and view().visit.rewarded,"exact reward retry confirmed"):return
	var after:=snapshot()
	var oldhero: Dictionary=before.campaign.characters.heroes[founder]
	var newhero: Dictionary=after.campaign.characters.heroes[founder]
	var source: String=after.campaign.characters.get("estate_reward",{}).get("source","")
	if not ck(source.begins_with("quest/liuxi/") and after.campaign.characters.estate_reward.actor_id==founder,"personal reward source present and unique"):return
	var expected := preload("res://campaign/character/hero_domain.gd").apply(oldhero,"outcome",{"kind":"skill","skill":"stewardship","amount":60,"source":"qa/reward-control"},view().day)
	ck(expected.ok and newhero.skills==expected.value.skills and oldhero.skills.stewardship!=newhero.skills.stewardship,"recipient actual skill experience equals exactly sixty configured training units")
	ck(newhero.sources==oldhero.sources,"opaque legacy character source records preserved apart from the new separate reward receipt")
	ck(after.campaign.characters.heroes[heir]==before.campaign.characters.heroes[heir] and after.campaign.inventory==before.campaign.inventory and after.campaign.governance==before.campaign.governance,"no skill granted to issuer and no items or estate changed by payout")
	ck(after.session.commands.size()==before.session.commands.size()+1 and app.dispatch(event,player)==receipt and not cmd("second-pay","visit_claim").ok,"one receipt and one award over both retry forms")
	ck(not outcome(source,"skill",founder,{"skill":"stewardship","amount":60}).ok and snapshot()==after,"generic trusted skill event cannot reuse quest-owned source")
	ck(not outcome("quest/liuxi/unrelated","skill",heir,{"skill":"leadership","amount":999}).ok,"reserved prefix cannot mint reward through otherwise trusted outcomes")
	ck(not cmd("forged-service","estate_service",{}).ok and snapshot()==after,"internal service action is not exposed as a player command")
	var restored:=Camp.new()
	var raw:Dictionary=after.campaign.duplicate(true)
	raw.characters.erase("estate_reward")
	ck(not restored.restore(raw).ok,"paid quest cannot restore without its CHR payment receipt")
	raw=after.campaign.duplicate(true)
	raw.erase("estate_commission")
	ck(not restored.restore(raw).ok,"character reward receipt without matching quest rejected")
	raw=after.campaign.duplicate(true)
	raw.estate_commission.schema_version=2
	ck(not restored.restore(raw).ok,"unknown commission version fails closed")
	raw=after.campaign.duplicate(true)
	raw.estate_commission.ledger.prosperity_after=1001
	ck(not restored.restore(raw).ok,"out-of-range signed daily ledger rejected")
	if not cold():return
	ck(app.dispatch(event,player)==receipt and view().visit.rewarded and not view().visit.can_accept,"loaded terminal state and receipt remain final")
	var report := {"actor":founder,"issuer":heir,"accepted":3,"ledger":ledger.day,"answered":6,"correct_tenths":ledger.prosperity_after-ledger.prosperity_before,"skill_before":oldhero.skills.stewardship,"skill_after":newhero.skills.stewardship,"source":source}
	print("MEASUREMENT ",JSON.stringify(report))

func expiry_path() -> void:
	if not ready():return
	for number in 3:
		if not day("expiry-%s"%number):return
	ck(view().day==7 and view().visit.status=="expired" and not view().visit.reason.is_empty(),"D+4 expires with journal explanation")
	ck(not cmd("late","visit_report",answers(4)).ok and not cmd("late-claim","visit_claim").ok,"late turn-in and payment refused")
	ck(not cmd("too-soon","visit_accept",args()).ok,"failure cooldown prevents same-day refresh")
	if not cold() or not day("next-chance"):return
	ck(view().visit.can_accept and cmd("reopen","visit_accept",args()).ok and view().visit.accepted_day==8 and view().visit.ledger.is_empty(),"retry next day starts fresh timeline and clears stale ledger")

func heir_path() -> void:
	var signed := OS.get_environment("P5_QA_SCENARIO")=="unclaimed"
	if signed and (not ready() or not finish()):return
	if not ck(cmd("retire","retire",{"heir_id":heir}).ok,"real retirement hands office to successor"):return
	var v:=view()
	ck(v.player_id==heir and v.governance.governor_id==null,"new family leader no longer a governor")
	ck(not v.visit.can_claim and not cmd("heir-paid","visit_claim").ok and not snapshot().campaign.characters.has("estate_reward"),"new head cannot inherit original actor's outstanding experience")
	if not signed:
		ck(v.visit.status=="failed" and not v.visit.reason.is_empty(),"active contract closed on original actor's retirement")
	cold()

func lost_issuer() -> void:
	if not ready():return
	var stale := envelope("disappeared","visit_report",answers(4))
	if not ck(outcome("lost-issuer","death",heir).ok,"authoritative death of old governor committed"):return
	ck(view().visit.speaker==null and view().visit.status=="failed" and not view().visit.reason.is_empty(),"departed governor disappears and job fails explicitly")
	ck(not app.dispatch(stale,player).ok and not cmd("refreshed","visit_report",answers(4)).ok and not cmd("refreshed-pay","visit_claim").ok,"precomputed and freshly forged report denied after issuer death")
	if not cold():return
	ck(view().visit.speaker==null and not view().visit.can_accept,"empty office after reload has no phantom NPC")

func absence() -> void:
	if not ck(outcome("travel","join",founder,{"location":PARTY}).ok,"leader departs home with an actual party"):return
	ck(not view().visit.can_visit and not cmd("away-report","visit_report",answers(4)).ok and view().visit.status=="active","away visitor cannot converse; original commission survives")
	if not ck(outcome("return","leave",founder,{"location":"character:place/home"}).ok and view().visit.can_visit,"return home unlocks audience"):return
	if not ck(outcome("captured","capture",founder,{"location":PARTY}).ok,"actor captured by trusted outcome"):return
	ck(not view().visit.can_visit and view().visit.status=="active" and not cmd("captive-pay","visit_claim").ok,"temporary incapacity keeps live job and hides permissions")
	if not day("captive-day"):return
	ck(view().visit.status=="ready" and not view().visit.can_report and not cmd("captive-report","visit_report",answers(4)).ok,"objective may progress while reporting privileges are suspended")
	if not ck(outcome("release","release",founder).ok,"actor freed"):return
	ck(view().visit.can_visit and view().visit.can_report,"return at home restores eligibility")
	if not finish():return
	if not ck(outcome("injured","wound",founder,{"severity":30}).ok,"real wounded state"):return
	ck(not view().visit.can_claim and not cmd("wounded-pay","visit_claim").ok and not view().visit.rewarded,"wound suspends unclaimed reward")
	cold()
