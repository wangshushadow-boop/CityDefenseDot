"""Summarize final P5 QA; preserve initial failures and original physical profiles in two fixture archives."""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import subprocess
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
p = argparse.ArgumentParser()
p.add_argument("commit")
p.add_argument("pack",type=Path)
p.add_argument("source_prefix")
p.add_argument("pack_prefix")
args=p.parse_args()
commit=subprocess.check_output(["git","rev-parse",args.commit],cwd=ROOT,text=True).strip()
manifest=json.loads((args.pack.parent/"manifest.json").read_text("utf8"))
assert manifest["git_commit"]==commit
digest=hashlib.sha256(args.pack.read_bytes()).hexdigest()
assert manifest["artifacts"]["client.pck"]["sha256"]==digest
scenarios=["success","expiry","succession","unclaimed","disappear","away","collision"]
suites=["estate_commission","visit_people","estate_campaign","visit_session","estate_desktop"]
matrix={"old_build":["legacy-client","legacy-reopen","legacy-collision"],
        "cold_source":[args.source_prefix+"-"+x for x in scenarios+suites+["history"]],
        "release_pck":[args.pack_prefix+"-"+x for x in scenarios+["estate_desktop","history"]]}
results=[]
totals={}
for group,labels in matrix.items():
    total=0
    for label in labels:
        data=json.loads((HERE/(label+".json")).read_text("utf8"))
        assert data["status"]=="PASS" and data["exit_code"]==0 and not data["error_output"],label
        if group=="release_pck": assert data["pack_sha256"]==digest,label
        stdout=HERE/(label+".log")
        assert hashlib.sha256(stdout.read_bytes()).hexdigest()==data["stdout_sha256"],label
        n,fail=map(int,data["counts"][-1]);assert n>0 and fail==0,label
        total+=n
        results.append({"label":label,"group":group,"status":"PASS","exit_code":0,"assertions":n,"log":label+".log"})
    totals[group]=total
earlier=[]
for f in sorted(HERE.glob("*.json")):
    data=json.loads(f.read_text("utf8"))
    if data.get("status")=="FAIL":
        earlier.append({"label":f.stem,"exit_code":data["exit_code"],"counts":data["counts"],"log":f.stem+".log"})
base=json.loads((HERE/"baseline.json").read_text("utf8"))
seed=json.loads((HERE/"collision.json").read_text("utf8"))
for label,name in [("legacy",base["save_sha256"]),("collision",seed["sha256"])]:
    assert hashlib.sha256((HERE/(label+"-save.zip")).read_bytes()).hexdigest()==name
measured=json.loads(next(l.removeprefix("MEASUREMENT ") for l in (HERE/(args.pack_prefix+"-success.log")).read_text("utf8").splitlines() if l.startswith("MEASUREMENT ")))
capture=HERE/("captures-"+args.pack_prefix+"-estate_desktop")/"estate-audience.png"
w,h=struct.unpack(">II",capture.read_bytes()[16:24])
summary={"status":"PASS","task":"P5-VISIT-QA","test_ids":["T-VISIT-01","T-VISIT-02"],"game_commit":commit,"client_sha256":digest,"engine":manifest["engine_version"],"display":"Windows Vulkan Forward+ RTX 3090","screenshot":{"width":w,"height":h,"sha256":hashlib.sha256(capture.read_bytes()).hexdigest()},"old_build":"9b975cc1b1809b620415aa64101e74df8b351252","old_pack_sha256":base["old_pack_sha256"],"old_governor":base,"old_colliding_event":seed,"results":results,"assertions_by_group":totals,"measured":measured,"initial_failures":earlier,"notes":["Cold source and packed suites overlap; do not add the groups as unique coverage.","A first-pass QA driver used a StringName answer key instead of a JSON string. Corrected and retained pre-*.log/JSON.","Early CHR reward published a StringName key and could not be encoded; corrected in f25ba23, before/after evidence retained.","Initial f8c9bdb application test used an invalid answer key. The real UI and independent driver used a string. Corrected and rerun in final candidate.","Initial f8c9bdb accepted a historical ledger containing an impossible 500000 governor bonus once the latest settlement ledger moved on; tested again on source and PCK."],"not_run":["Physical gamepad and screen reader","Subjective human playtest","Full P5 or free-roaming town missions","P2 battle performance"]}
(HERE/"summary.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2)+"\n","utf8")
with zipfile.ZipFile(HERE/"qa-evidence.zip","w",zipfile.ZIP_DEFLATED) as archive:
    for f in sorted(HERE.iterdir()):
        if f.is_file() and (f.suffix in [".gd",".py",".json",".log"] or f.name in ["legacy-save.zip","collision-save.zip"]):archive.write(f,f.name)
    for f in HERE.glob("captures-*/*.png"):archive.write(f,f.relative_to(HERE))
with zipfile.ZipFile(HERE/"qa-evidence.zip") as z:assert z.testzip() is None
print(json.dumps({"totals":totals,"early_failures":len(earlier),"sha256":hashlib.sha256((HERE/"qa-evidence.zip").read_bytes()).hexdigest(),"capture":str(capture)},ensure_ascii=False))
