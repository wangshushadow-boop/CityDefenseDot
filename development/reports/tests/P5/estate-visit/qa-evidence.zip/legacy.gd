extends SceneTree
const Boot = preload("res://bootstrap/composition_root.gd")
const Config = preload("res://bootstrap/boot_config.gd")
const Store = preload("res://infrastructure/persistence/save_service.gd")
const Canon = preload("res://contracts/canonical.gd")
const SLOT := "oldgovernor"
var boot: RefCounted
var checks := 0
var failures := 0

func ck(ok: bool, label: String) -> bool:
	checks += 1
	if not ok:
		printerr("FAIL ",label)
		failures += 1
	else:
		print("PASS ",label)
	return ok

func _initialize() -> void:
	run.call_deferred()

func cmd(id: String, op: String, args: Dictionary={}) -> bool:
	var view: Dictionary = boot.character_view().value
	return ck(boot.character_command(op,args,view.revision,id).ok,op+" at "+str(view.revision))

func run() -> void:
	boot = Boot.new(root)
	var cfg := Config.resolve([],DisplayServer.get_name(),{})
	if ck(cfg.ok and boot.boot(cfg.value).ok,"start P4 production boot") and ck(boot.new_world(SLOT).ok,"actual sandbox created"):
		create_governor()
	boot.shutdown()
	print("P4_OLD_GOVERNOR checks=%d failures=%d"%[checks,failures])
	quit(int(failures!=0))

func create_governor() -> void:
	if not cmd("old-create","create",{"name":"令秋","culture":"river"}):return
	if not cmd("old-open","governor_open"):return
	var family: Dictionary = boot.character_view().value
	var cousin: String = family.heirs[0].id
	if not cmd("old-assign","governor_assign",{"settlement_id":family.governance.settlement_id,"hero_id":cousin}):return
	for i in 3:
		if not cmd("old-rest-%s"%i,"rest"):return
	var model: Dictionary = boot.character_view().value
	var disk: Dictionary = Store.new().recover(SLOT).value.snapshot
	ck(model.day==3 and model.family.size()==2 and model.governance.governor_id==cousin,"three full days, two live people and commissioned cousin")
	ck(model.governance.last_report.governor_id==cousin and model.governance.prosperity==512,"actual settled ledger")
	ck(disk.session.commands.size()==6 and disk.campaign.inventory!=null,"existing inventory and six physical receipts")
	var replay: Dictionary = boot.character_command("create",{"name":"令秋","culture":"river"},0,"old-create")
	ck(replay.ok and boot.character_view().value==model,"old create receipt replays exactly once")
	ck(boot.session().close_session().ok and boot.load_world(SLOT).ok and boot.character_view().value==model,"close and reload physical save")
	print("P4_ARCHIVE ",JSON.stringify({"world":disk.world_id,"clan":disk.campaign.characters.household.id,"hero":model.player_id,"heir":cousin,"settlement":model.governance.settlement_id,"day":model.day,"minute":disk.game_minute,"content_hash":disk.content_hash,"inventory_hash":Canon.hash_value(disk.campaign.inventory).value,"governance_hash":Canon.hash_value(disk.campaign.governance).value,"character_hash":Canon.hash_value(disk.campaign.characters).value,"receipt_hash":Canon.hash_value(disk.session.commands).value}))
