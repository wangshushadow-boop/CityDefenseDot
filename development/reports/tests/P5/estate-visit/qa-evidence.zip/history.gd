extends SceneTree
const Camp=preload("res://campaign/runtime.gd")
const Store=preload("res://infrastructure/persistence/save_service.gd")
const Canon=preload("res://contracts/canonical.gd")
func _initialize() -> void:
	var snap: Dictionary=Store.new().recover("oldgovernor").value.snapshot.campaign
	var entry: Dictionary=snap.estate_commission.ledger
	if snap.governance.last_day<=entry.day or not Camp.new().restore(snap).ok:
		print("SETUP FAILED")
		quit(1)
		return
	entry.prosperity_bonus=500000
	entry.prosperity_after=1000
	var accepted: Dictionary=Camp.new().restore(snap)
	var checks:=1
	var failures:=int(accepted.ok)
	print("Historical report with implausible officer contribution: ",accepted)
	if snap.estate_commission.has("ledger_hash"):
		snap.estate_commission.ledger_hash=Canon.hash_value(entry).value
		var forged: Dictionary=Camp.new().restore(snap)
		checks+=1
		failures+=int(forged.ok)
		print("Recomputed journal digest still requires actual ducal skill limit: ",forged)
	print("HISTORICAL_BOUNDS checks=",checks," failures=",failures)
	quit(int(failures>0))
